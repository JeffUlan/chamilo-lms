<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langActivate = "Etkinle�tir";
$langDeactivate = "Etkinli�ini Kald�r";
$langInLnk  = "Kald�r�lm�� ba�lant�lar";
$langDelLk = "Bu ba�lant�y� silmek istiyor musunuz?";
$langEnter  = "Giri�";
$langCourseCreate  = "Ders web sitesi olu&#351;tur";
$langNameOfTheLink  = "Ba�lant� ad�";
$lang_main_categories_list                  = "Ana kategori listesi";
$langCourseAdminOnly = "Sadece �&#287;retmenler";
$PlatformAdminOnly = "Sadece Platform Y�neticileri";
$langCombinedCourse = "Birle&#351;tirilmi&#351; dersler";
$ToolIsNowVisible = "Bu ara� &#351;imdi g�r�lebilir";
$ToolIsNowHidden = "Bu ara� &#351;imdi g�r�lmez";
$EditLink = "Ba&#287;lant&#305; ekle";
?>