<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langLinkName = "Ba�lant� ad�";
$langLinkAdd = "Ba&#287;lant&#305; ekle";
$langLinkAdded = "Ba&#287;lant&#305; eklendi";
$langLinkMod = "Ba&#287;lant&#305; d�zenle";
$langLinkModded = "Ba&#287;lant&#305; d�zenlendi";
$langLinkDel = "Ba&#287;lant&#305; sil";
$langLinkDeleted = "Ba&#287;lant&#305; silindi";
$langLinkDelconfirm = "Ba&#287;lant&#305;y&#305; silmek istiyormusunuz?";
$langAllLinksDel = "Bu kategorideki b�t�n ba&#287;lant&#305;lar&#305; sil";
$langCategoryName = "Kategori ismi";
$langCategoryAdd = "Kategori ekle";
$langCategoryAdded = "Kategori eklendi.";
$langCategoryMod = "Kategori d�zenle";
$langCategoryModded = "Kategori d�zenlendi.";
$langCategoryDel = "Kategori sil";
$langCategoryDeleted = "Bu kategori ve i�indeki ba&#287;lant&#305;lar&#305;n hepsi silindi.";
$langCategoryDelconfirm = "Kategori silindi&#287;inde i�indeki ba&#287;lant&#305;lar&#305;n tamam&#305; da silinecektir, bu kategoriyi silmek istiyormusunuz ?";
$langAllCategoryDel = "B�t�n kategorileri ve ba&#287;lant&#305;lar&#305; sil";
$langGiveURL = "L�tfen ba&#287;lant&#305;n&#305;n adresini (URL) yaz&#305;n";
$langGiveCategoryName = "L�tfen kategori ismini yaz&#305;n";
$langNoCategory = "Herhangi bir kategori bulunmuyor.";
$showall = "B�t�n kategorileri g�ster";
$shownone = "Kategorileri g�sterme";
$langListDeleted = "Liste silindi";
$langAddLink = "Ba�lant� ekle";
$langDelList = "T�m listeyi sil";
$langModifyLink = "Ba&#287;lant&#305; d�zenle";
$langCsvImport = "Sunucuya bir CSV dosyas&#305; g�nder";
$langCsvFileNotFound = "CSV y�kleme dosyas&#305; a�&#305;lamad&#305; (bo&#351;, �ok b�y�k vs)";
$langCsvFileNoSeps = "Csv dosyas&#305;nda liste ay&#305;rac&#305; olarak , veya ; kullan&#305;lmal&#305;d&#305;r.";
$langCsvFileNoURL = "CSV dosyas&#305;nda URL ve ba&#351;l&#305;k olmak �zere en az iki s�tun bulunmal&#305;d&#305;r.";
$langCsvFileLine1 = "... - sat&#305;r 1 =";
$langCsvLinesFailed = "sat&#305;r(lar) ba&#287;lant&#305; y�klemede ba&#351;ar&#305;s&#305;z oldu ( URL veya ba&#351;l&#305;k bulunmuyor)";
$langCsvLinesOld = "mevcut ba&#287;lant&#305;(lar) g�ncellendi (ayn&#305; URL ve kategori)";
$langCsvLinesNew = "yeni ba&#287;lant&#305; olu&#351;turuldu.";
$langCsvExplain = "Dosya yap&#305;s&#305; &#351;�yle olmal&#305;d&#305;r<blockquote> <b>URL</b>;kategori;<b>ba&#351;l&#305;k</b>;a�&#305;klama; <b>http://www.aaa.org/...</b>;�nemli ba&#287;lant&#305;lar;<b>&#304;sim 1</b>;A�&#305;klama 1; <b>http://www.bbb.net/...</b>;;<b>&#304;sim 2</b>;\"A�&#305;klama 2\"; </blockquote>E&#287;er URL ve kategori mevcut olanlar ile ayn&#305; ise sadece ba&#351;l&#305;k ve a�&#305;klama g�ncellenir.Di&#287;er b�t�n durumlarda yeni bir ba&#287;lant&#305; olu&#351;turulur.<br><br>Koyu = zorunlu.Alanlar herhangi bir s&#305;ra ile olabilir, isimler b�y�k veya k���k harf olabilir.&#304;lave alanlar a�&#305;klamaya eklendi.Ay&#305;ra�: virg�l veya noktal&#305; virg�l. De&#287;erler kotalanabilir ama alan isimleri de&#287;il. A�&#305;klama alan&#305;na baz&#305; [b]HTML komutlar&#305;[/b] yaz&#305;labilir.";
$langLinkUpdated = "Link g�ncellendi";
$langAll_Link_Deleted = "Ba&#287;lant&#305; silindi";
$langOnHomepage = "Ba&#287;lant&#305;y&#305; AnaSayfada g�ster";
$langShowLinkOnHomepage = "Bu ba&#287;lant&#305;y&#305; Ders AnaSayfas&#305;nda simge olarak g�ster";
$langCsvImport = "CSV al";
?>