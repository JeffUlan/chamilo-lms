<?php /*
for more information: see languages.txt in the lang folder. 
*/
$Tools  = "Ara�lar";
$langDownloadFile = "Belge y�kle";
$langTooBig = "Bir dosya se�mediniz veya �ok b�y�k.";
$langListDeleted = "T�m liste silindi.";
$langDocModif = "belge ba&#351;l&#305;&#287;&#305; de&#287;i&#351;tirildi";
$langDocAdd = "Belge eklendi";
$langDocDel = "Belge silindi";
$langTitleWork = "Belge ba&#351;l&#305;&#287;&#305;";
$langAuthors = "Yazarlar";
$langDelList = "T�m listeyi sil";
$langWorkDelete = "sil";
$langWorkModify = "D�zenle";
$langWorkConfirmDelete = "bu dosyay&#305; silmek istediginizden emin misiniz?";
$langAllFiles = "B�t�n dosyalardaki i&#351;lemler";
$lang_default_upload = "Yeni g�nderilen dosyalar&#305;n varsay&#305;lan ayarlar&#305;";
$lang_new_visible = "B�t�n kullan&#305;c&#305;lar g�rebilir";
$lang_new_unvisible = "Sadece ders yetkilisi g�rebilir";
$lang_doc_unvisible = "Dosyan&#305;z sadece ders yetkilisi taraf&#305;ndan g�r�lebilir oldu&#287;u i�in siz g�remeyeceksiniz.";
$langDelLk = "Ba&#287;lant&#305; sil";
$langMustBeRegisteredUser = "Sadece bu dersin kay&#305;tl&#305; kullan&#305;c&#305;lar&#305; dosya g�nderebilir.";
$langListDel = "Listeyi sil";
$langNameDir = "Klas�r� yeniden isimlendir";
$langFileExists = "Dosya zaten mevcut.";
$langDirCr = "Klas�r olu&#351;tur";
$langCurrentDir = "Aktif Dizin";
$UploadADocument = "Belge g�nder";
$EditToolOptions = "Kelime i&#351;lemci ara� se�enekleri";
$DocumentDeleted = "Belge Silindi";
?>