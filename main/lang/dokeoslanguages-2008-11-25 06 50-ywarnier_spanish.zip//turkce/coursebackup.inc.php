<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langSelectOptionForBackup = "L�tfen bir yedekleme se�ene&#287;i se�iniz";
$langLetMeSelectItems = "Ders elemanlar&#305;n&#305; ben se�eyim";
$langCreateFullBackup = "Bu dersin tamam&#305;n&#305; yedekle";
$langCreateBackup = "bir yedek olu&#351;tur";
$langBackupCreated  = "Ders yede&#287;i olu&#351;turuldu.Dosya indirme ba&#351;lamak �zere, e&#287;er dosya indirme ba&#351;lamazsa ilgili ba&#287;lant&#305;ya t&#305;klay&#305;n.";
$langSelectBackupFile = "yedek dosyas&#305; se�in";
$langImportBackup = "Yedek dosyas&#305;n&#305; sisteme yolla";
$langImportFullBackup = "Tam Yedek dosyas&#305;n&#305; sisteme yolla";
$langImportFinished = "Dosya g�nderme tamamland&#305;";
$langEvents = "Olaylar";
$langAnnouncements = "Duyurular";
$langDocuments  = "Belgeler";
$langTests = "Al&#305;&#351;t&#305;rmalar";
$langLearnpaths = "Kurslar";
$langCopyCourse = "Dersi kopyala";
$langSelectItemsToCopy = "Kopyalama i�in se�iniz";
$langCopyFinished = "Kopyalama bitti";
$langFullRecycle = "Tam geri d�n�&#351;�m";
$langRecycleCourse = "Kursu geri d�n�&#351;t�r";
$langRecycleFinished = "Geri d�n�&#351;�m bitti";
$langRecycleWarning = "D&#304;KKAT: Bu arac&#305; kullan&#305;rsan&#305;z kursunuzun baz&#305; par�alar&#305;n&#305; sileceksiniz. Bu i&#351;lem geri al&#305;namaz. Size bu i&#351;lemi yapmadan �nce<a href=\"create_backup.php\">bu sayfay&#305;  </a>kullanarak yedeklemenizi tavsiye ediyoruz.";
$langSameFilename = "D&#305;&#351;ar&#305;dan al&#305;nan dosyalarda, varolan dosyalarla ayn&#305; dosya ismine sahip olanlar&#305; ne yapmak istersiniz?";
$langSameFilenameSkip = "Ayn&#305; dosya ismini atla";
$langSameFilenameRename = "Rename file (eg file.pdf becomes file_1.pdf)";
$langSameFilenameOverwrite = "Overwrite file";
$langSelectDestinationCourse = "Select destination course";
$langFullCopy  = "Full copy";
$langCourseDescription = "Ders a�&#305;klamas&#305;";
$langNoResourcesToBackup = "There are no resources to backup";
$langNoResourcesInBackupFile = "There are no resources in backup file";
$langSelectResources = "Select resources";
$langNoResourcesToRecycles = "There are no resources to recycle";
$langIncludeQuestionPool = "Include questions pool";
$langLocalFile = "lokal dosya";
$langServerFile = "sunucudaki dosya";
$langNoBackupsAvailable = "no backup is available";
$langNoDestinationCoursesAvailable = "Kullan&#305;labilir hedef ders bulunmuyor";
$langBackup = "Yedekle";
$langImportBackupInfo = "Import a backup. You will be able to upload a backup file from you local drive or you can use a backup file available on the server.";
$langCreateBackupInfo = "Create a backup of this course. You can select the course contents to put in the backup file.";
$ToolIntro = "Tool introduction";
?>