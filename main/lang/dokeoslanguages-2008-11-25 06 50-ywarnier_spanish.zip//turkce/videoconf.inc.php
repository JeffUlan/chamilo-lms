<?php /*
for more information: see languages.txt in the lang folder. 
*/
$Camera = "Kamera";
$Microphone = "Mikrofon";
$Name = "&#304;sim";
$RefreshList = "Listeyi g�ncelle";
$GoToTop = "Yukar&#305; git";
$NewPoll = "Yeni anket";
$Accept = "Kabul et";
?>