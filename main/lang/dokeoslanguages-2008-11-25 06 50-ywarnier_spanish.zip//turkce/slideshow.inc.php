<?php /*
for more information: see languages.txt in the lang folder. 
*/
$lang_height = "Y�kseklik";
$lang_resizing_comment = "g�r�nt�y� &#351;u boyutlara g�re ayarla (pixel olarak)";
$lang_width = "Geni&#351;lik";
$lang_resizing = "YEN&#304;DEN BOYUTLANDIR";
$lang_no_resizing_comment = "Show all images in their original size. No resizing is done. Scrollbars will automatically appear if the image is larger than your monitor size.";
$lang_show_thumbnails = "T&#305;rnak resimleri g�ster";
$lang_click_thumbnails = "T&#305;rnak resimlerden birine t&#305;klay&#305;n";
$lang_set_slideshow_options = "Slayt G�sterisi se�eneklerini ayarla";
$lang_slideshow_options = "Slayt G�sterisi se�enekleri";
$lang_no_resizing = "YEN&#304;DEN BOYUTLANDIRMA YOK (Varsay&#305;lan)";
$lang_exit_slideshow = "Slayt g�sterisinden �&#305;k";
$SlideShow = "Slayt G�sterisi";
$lang_previous_slide = "�nceki Slayt";
$lang_next_slide = "Sonraki Slayt";
$lang_image = "Resim";
$lang_of = "/";
$lang_view_slideshow = "Slayt G�sterisini g�r�nt�le";
?>