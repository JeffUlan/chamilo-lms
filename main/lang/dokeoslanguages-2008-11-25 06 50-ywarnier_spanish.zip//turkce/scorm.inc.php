<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langScormVersion = "versiyon";
$langScormRestarted = "&#350;imdilik tamamlanmam&#305;&#351; dersler.";
$langScormNoNext = "Bu son ders.";
$langScormNoPrev = "Bu ilk ders.";
$langScormTime = "Zaman";
$langScormNoOrder = "Verilmi&#351; sipari&#351; yok, herhangi bir dersin �zerine t&#305;klayabilirsiniz.";
$langScormScore = "Sonu�";
$langScormLessonTitle = "B�l�m ba&#351;l&#305;&#287;&#305;";
$langScormStatus = "Durum";
$langScormToEnter = "Giri&#351;";
$langScormFirstNeedTo = "�ncelikle tamamlamal&#305;s&#305;n&#305;z";
$langScormThisStatus = "&#350;imdi bu ders";
$langScormClose = "Sonland&#305;r";
$langScormRestart = "Yeniden ba&#351;lat";
$langScormCompstatus = "tamamland&#305;";
$langScormIncomplete = "Tamamlanmad&#305;";
$langScormPassed = "Ge�ti";
$langScormFailed = "Ba&#351;ar&#305;s&#305;z";
$langScormPrevious = "�nceki";
$langScormNext = "Sonraki";
$langScormTitle = "Dokeos Scorm oyuncusu";
$langScormMystatus = "Durumum";
$langScormNoItems = "Bu ba&#351;l&#305;k hi� bir alt ba&#351;l&#305;k i�ermiyor.";
$langScormNoStatus = "Bu ba&#351;l&#305;k i�in durum yok";
$langScormLoggedout = "Scrom alan&#305;ndan �&#305;k&#305;ld&#305;.";
$langScormCloseWindow = "Pencereleri kapat";
$langScormExitFullScreen = "Normal ekrana d�n";
$langScormFullScreen = "Tam Ekran";
$langScormNotAttempted = "�al&#305;&#351;mad&#305;";
$langUnknown = "Bilinmiyor";
?>