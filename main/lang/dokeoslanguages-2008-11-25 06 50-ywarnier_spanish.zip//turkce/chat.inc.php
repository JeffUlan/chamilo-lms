<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langOnlineConference  = "Konferans";
$langWash  = "Temizle";
$langReset  = "S&#305;f&#305;rla";
$langSave  = "Kaydet";
$langRefresh  = "Yenile";
$langIsNowInYourDocDir  = " belge ara�lar&#305;n&#305;zdad&#305;r. <br><B>Bu dosya <u>g�r�n�r</u></B>";
$langCopyFailed  = "Yazd&#305;rma i&#351;lemi tamamlanamad&#305;";
$langTypeMessage  = "L�tfen mesaj&#305;n&#305;z&#305; yaz&#305;n&#305;z!";
$langConfirmReset  = "B�t�n mesajlari silmek istiyormusunuz?";
$langHasResetChat  = "Sohbet\'i temizledi.";
$langNoOnlineConference  = "&#350;u anda herhangi bir konferans bulunmuyor...";
$langMediaFile  = "Canl&#305; ses veya resim ak&#305;&#351;&#305;";
$langContentFile  = "Sunum";
$langListOfParticipants  = "Kat&#305;lanlar&#305;n listesi";
$langYourPicture  = "Resminiz";
$langOnlineDescription  = "Konferans A�&#305;klamas&#305;";
$langOnlyCheckForImportantQuestion = "Bu kutuyu sadece �NEML&#304; bir soru soraca&#287;&#305;n&#305;z zaman i&#351;aretleyin l�tfen !";
$langQuestion = "soru";
$langClearList = "Listeyi temizle";
$langWhiteBoard = "Beyaz Tahta";
$langTextEditorDefault = "<h2>Kelime &#304;&#351;lemci</h2>MS Word dosyas&#305;ndan kesip buraya yap&#305;&#351;t&#305;r&#305;n ve d�zenleyin.Kat&#305;l&#305;mc&#305;lar de&#287;i&#351;iklikleri canl&#305; olarak izleyecektir. ";
$langStreaming = "Veri ak&#305;&#351;&#305;";
$langStreamURL = "Veri ak&#305;&#351;&#305; URL";
$langStreamType = "Veri ak&#305;&#351; t�r�";
$langLinkName = "Ba&#287;lant&#305; ismi";
$langLinkURL = "Ba&#287;lant&#305; URL";
$langWelcomeToOnlineConf = "<b>Canl&#305; Konferansa Ho&#351;geldiniz</b>";
$langNoLinkAvailable = "Kullan&#305;labilir ba&#287;lant&#305; bulunmuyor";
$langChat_reset_by = "sohbeti s&#305;f&#305;rla";
$OrFile = "Veya dosya";
$langCallSent = "Sohbet iste&#287;iniz g�nderildi, cevap bekleniyor.";
$langChatDenied = "�a&#287;r&#305;n&#305;z kabul edilmedi.";
?>