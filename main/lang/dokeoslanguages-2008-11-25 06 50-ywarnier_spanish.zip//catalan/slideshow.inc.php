<?php /*
for more information: see languages.txt in the lang folder. 
*/
$lang_height = "Altura";
$lang_resizing_comment = "redimensionar la imatge amb el seg�ent tamany (en pixels)";
$lang_width = "Amplaria";
$lang_resizing = "Redimensionar";
$lang_no_resizing_comment = "Mostrar totes les imatges al tamany original. No redimensionar s\'ha activat. Les barres de despla�ament apareixeran autom�ticament si la imatge �s m�s gran que el tamany de la seva pantalla.";
$lang_show_thumbnails = "Mostrar miniatures";
$lang_click_thumbnails = "Clic a una de les miniatures";
$lang_set_slideshow_options = "Modificar les opcions de la presentaci�";
$lang_slideshow_options = "Opcions de la presentaci�";
$lang_no_resizing = "No redimensionar (per defecte)";
$lang_exit_slideshow = "Sortir de la presentaci�";
$SlideShow = "Presentaci�";
$lang_previous_slide = "Diapositiva anterior";
$lang_next_slide = "Diapositiva seg�ent";
$lang_image = "Imatge";
$lang_of = "de";
$lang_view_slideshow = "Veure presentaci�";
?>