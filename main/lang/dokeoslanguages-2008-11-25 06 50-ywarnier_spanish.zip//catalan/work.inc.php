<?php /*
for more information: see languages.txt in the lang folder. 
*/
$Tools  = "Eines";
$langDownloadFile = "Penja un document";
$langTooBig = "No has escollit cap fitxer o el fitxer �s massa gran.";
$langListDeleted = "La llista sencera ha estat esborrada.";
$langDocModif = "t�tol del treball modificat";
$langDocAdd = "Treball afegit";
$langDocDel = "Treball esborrat";
$langTitleWork = "T�tol del treball";
$langAuthors = "Autors";
$langDelList = "Esborra la llista sencera";
$langWorkDelete = "Eliminar";
$langWorkModify = "Modificar";
$langWorkConfirmDelete = "Segur que vols esborrar aquest arxiu";
$langAllFiles = "Tots els arxius";
$lang_default_upload = "Configuraci� per defecte per a la visualitzaci� dels nous arxius enviats";
$lang_new_visible = "Els nous documents s�n visibles per a tots els usuaris";
$lang_new_unvisible = "Els nous documents s�n nom�s visibles per als administradors de cursos";
$lang_doc_unvisible = "L\'arxiu nom�s �s visible per al professor d\'aquest curs, tampoc el pots veure tu";
$langDelLk = "Esborrar enlla�";
$langMustBeRegisteredUser = "Nom�s els usuaris inscrits en aquest curs poden publicar documents";
$langListDel = "Eliminar llista";
$langNameDir = "Canviar nom al directori";
$langFileExists = "L\'arxiu ja existeix";
$langDirCr = "Crear directori";
$langCurrentDir = "Directori actual";
$UploadADocument = "Penjar un document";
$EditToolOptions = "Editar les opcions de les eines";
$DocumentDeleted = "Document esborrat";
$SendMailBody = "Un usuari ha publicat un document en l\'eina treballs del vostre curs";
$DirDelete = "Esborrar el directori";
$ValidateChanges = "Validar els canvis";
?>