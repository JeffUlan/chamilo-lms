<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langScormBuilder = "Constructor de cam� - constructor de curs de format Scorm";
?>