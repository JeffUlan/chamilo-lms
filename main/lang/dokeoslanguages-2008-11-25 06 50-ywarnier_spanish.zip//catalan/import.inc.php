<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langPgTitle = "T�tol de la p�gina";
$langExplanation = "La p�gina ha d\'estar en format HTML (ex: \"my_page.htm\"). Ser� enlla�ada des de la P�gina d\'Inici. Si vols enviar documents no-HTML (PDF, Word, Power Point, Video, etc.) utilitza <a href=../document/document.php>l\'eina de Documents</a>";
$langTooBig = "No has escollit cap fitxer a enviar, o �s massa gran";
$langCouldNot = "No s\'ha pogut enviar el fitxer";
$langNotAllowed = "No perm&ecute;s";
$langAddPageToSite = "Afegeix plana al lloc";
$langCouldNotSendPage = "Aquest fitxer no est� en format HMTL i no ha pogut ser enviat. Si vols enviar documents no-HTML (PDF, Word, Power Point, Video, etc.) utilitza <a href=../document/document.php>l\'eina de Documents</a>";
$langSendPage = "P�gina a enviar";
$langPageTitleModified = "El t�tol de la p�gina ha estat modificat";
$langPageAdded = "P�gina afegida";
$langAddPage = "Afegeix una p�gina";
?>