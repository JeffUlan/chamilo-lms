<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langLineNumber = "N�mero de l�nia";
$langLine = "L�nia";
$langLines = "L�nies";
$langLineOrLines = "L�nia/L�nies";
$langMoveUp = "Pujar";
$langMoveDown = "Baixar";
$langAddNewHeading = "Afegir nova cap�alera";
$langCourseAdministratorOnly = "Nom�s professors";
$langDefineHeadings = "Definir cap�aleres";
$langBackToUsersList = "Tornar a la llista d\'usuaris";
$langTracking = "Acompanyament";
$langCourseManager = "Professor";
$langModRight = "Canviar drets de";
$langNoAdmin = "A partir d\'ara <B>no</b> tens drets sobre aquesta p�gina";
$langAllAdmin = "A partir d\'ara <b>tens</b> drets sobre aquesta p�gina";
$langRole = "rol/estat";
$langIsNow = "est� a partir d\'ara";
$langInC = "en aquest curs";
$langFilled = "No has completat tots els camps";
$langUserNo = "Usuari no";
$langTaken = "Ja est� en �s, seleccioneu un diferent";
$langTutor = "Tutor";
$langUnreg = "Desinscriure\'s";
$langGroupUserManagement = "Administraci� del grup";
$langUserInfo = "Informaci� de l\'usuari";
$langUnregister = "Esborrar";
$langAddAUser = "Afegir usuaris";
?>