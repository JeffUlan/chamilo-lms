<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langActivate = "Activa";
$langDeactivate = "Desactiva";
$langInLnk  = "Enlla�os desactivats";
$langDelLk = "Voleu realment esborrar aquest enlla�?";
$langEnter  = "Entra";
$langCourseCreate  = "Crear un curs web";
$langNameOfTheLink  = "Nom de l\'enlla�";
$lang_main_categories_list                  = "Llista de categories principal";
$langCourseAdminOnly = "Nom�s professors";
$PlatformAdminOnly = "Nom�s administradors";
$langCombinedCourse = "Curs combinat";
$ToolIsNowVisible = "L\'eina �s actualment visible";
$ToolIsNowHidden = "L\'eina �s actualment no visible";
$EditLink = "Editar enlla�";
$Blog_management = "Gesti� de blocs";
$Forum = "F�rums";
$Course_maintenance = "Manteniment del curs";
$TOOL_SURVEY = "Enquestes";
$GreyIcons = "Caixa d\'eines";
$Interaction = "Interacci�";
$Authoring = "Creaci� de continguts";
$Administration = "Administraci�";
$IntroductionTextUpdated = "El text d\'introducci� ha estat actualitzat";
$IntroductionTextDeleted = "El text d\'introducci� ha estat eliminat";
?>