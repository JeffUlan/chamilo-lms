<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langCourseProgram  = "Descripci� del curs";
$langThisCourseDescriptionIsEmpty  = "Aquest curs actualment no es troba descrit";
$langEditCourseProgram  = "Crear i editar una descripci� del curs";
$QuestionPlan  = "Pregunta al professor";
$langInfo2Say  = "Informaci� a donar als estudiants";
$langOuAutreTitre  = "T�tol";
$langNewBloc  = "Altre";
$langAddCat  = "afegeix categoria";
$langAdd  = "Afegeix";
$langValid  = "Valida";
$langBackAndForget  = "Retrocededix i oblida";
$CourseDescriptionUpdated = "La descripci� dels curs ha estat actualitzada";
$CourseDescriptionDeleted = "La descripci� del curs ha estat esborrada";
$CourseDescriptionIntro = "Per crear una descripci� del curs, cliqueu sobre un apartat i ompliu els camps del formulari associat. <br> <br> Cliqueu despr�s a Validar i ompliu un altre apartat.";
?>