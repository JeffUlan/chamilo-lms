<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langMdCallingTool = "Enlla�os";
$langMdTitle = "Nom de l\'enlla�";
$langMdDescription = "Descripci� de l\'enlla�";
$langMdCoverage = "Universal";
$langMdCopyright = "Universitat de Gante";
$nameTools = "variable d\'idioma obsoleta";
$langTool = "Metainformaci� dels enlla�os";
$langIdentifier = "Identificador";
$langKeyword = "Paraules clau";
$langLocation = "URL/URI";
$langStore = "Emmagametzar";
$langDeleteAll = "Eliminar tota la metainformaci�";
$langWorkOn = "a";
$langContinue = "Continuar amb";
$langCreate = "Crear entrades de metadades (MDE)";
$langRemove = "Esborrar entrades de metadades";
$langIndex = "�ndex de paraules";
$langTotalMDEs = "Total d\'entrades de metadades (MD) d\'enlla�os";
?>