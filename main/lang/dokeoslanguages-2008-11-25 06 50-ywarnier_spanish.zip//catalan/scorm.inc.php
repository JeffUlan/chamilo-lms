<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langScormVersion = "versi�";
$langScormRestarted = "Totes les lli�ons estan incomplertes ara";
$langScormNoNext = "Aquesta �s la darrera lli��";
$langScormNoPrev = "Aquesta �s la primera lli��";
$langScormTime = "Temps";
$langScormNoOrder = "No hi ha una ordre establerta, pots clicar sobre qualsevol lli��";
$langScormScore = "Puntuaci�";
$langScormLessonTitle = "T�tol de la lli��";
$langScormStatus = "Situaci�";
$langScormToEnter = "Per introduir";
$langScormFirstNeedTo = "Primer necessites finalitzar";
$langScormThisStatus = "Aquesta lli�o est� ara";
$langScormClose = "Tancar aplicaci�";
$langScormRestart = "Reiniciar";
$langScormCompstatus = "Completat";
$langScormIncomplete = "Incomplert";
$langScormPassed = "Aprovat";
$langScormFailed = "Suspens";
$langScormPrevious = "Anterior";
$langScormNext = "Seg�ent";
$langScormTitle = "Visualitzador de continguts DOKEOS";
$langScormMystatus = "La meva situaci�";
$langScormNoItems = "Aquest contingut no t� elements";
$langScormNoStatus = "No hi ha situaci� per aquest contingut";
$langScormLoggedout = "Has sortit de l\'�rea SCORM";
$langScormCloseWindow = "Tancar finestres";
$langScormExitFullScreen = "Tornar a la pantalla normal";
$langScormFullScreen = "Pantalla completa";
$langScormNotAttempted = "Sense intentar";
?>