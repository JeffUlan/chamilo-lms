<?php /*
for more information: see languages.txt in the lang folder. 
*/
$lang_height = "Height";
$lang_resizing_comment = "resize the image to the following dimensions (in pixels)";
$lang_width = "Width";
$lang_resizing = "RESIZE";
$lang_no_resizing_comment = "Show all images in their original size. No resizing is done. Scrollbars will automatically appear if the image is larger than your monitor size.";
$lang_show_thumbnails = "Show Thumbnails";
$lang_click_thumbnails = "Click on one of the thumbnails";
$lang_set_slideshow_options = "Set Slideshow Options";
$lang_slideshow_options = "Slideshow Options";
$lang_no_resizing = "NO RESIZING (default)";
$lang_exit_slideshow = "Exit Slideshow";
$SlideShow = "Slideshow";
$lang_previous_slide = "Previous Slide";
$lang_next_slide = "Next Slide";
$lang_image = "Image";
$lang_of = "of";
$lang_view_slideshow = "View Slideshow";
?>