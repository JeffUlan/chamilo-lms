<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langTool = "元数据";
$langClickKw = "点击目录中的关键字进行选择或取消选择.";
$langKwHelp = "单击 \\\'+\\\' 按钮打开, \\\'-\\\' 按钮关闭, \\\'++\\\' 按钮全部打开, \\\'--\\\' 按钮全部关闭.<BR><BR>通过关闭目录树清除全部选定的关键词，再\\\'+\\\'按钮用打开。 按住Alt键并单击 \\\'+\\\'重新选定前一个选定的关键词.<BR><BR>按住Alt键并点击关键词以取消关键词。";
$langAdvanced = "高级";
$langSearch = "搜索";
$langSearchCrit = "请在下面空格填入简介, 每行一字!";
$langNoKeywords = "此课程无关键词";
$langKwCacheProblem = "关键词缓存无法打开";
$langCourseKwds = "课程关键词";
$langKwdsInMD = "MD 所使用的关键词";
$langKwdRefs = "关键词参考";
$langNonCourseKwds = "非课程关键词";
$langKwdsUse = "课程关键字(粗体就是未被使用) ";
$langTotalMDEs = "全部MD条目数量:";
?>