<?php /*
for more information: see languages.txt in the lang folder. 
*/
$lang_new_item = "添加新项目";
$lang_title_notification = "自上次访问以来";
$lang_update_agenda = "现有日程项目更新";
$lang_new_agenda = "新的日程项目已添加";
$lang_update_announcements = "现有公告已更新";
$lang_new_announcements = "新公告已添加";
$lang_new_document = "新文档已添加";
$lang_new_exercise = "新练习已可使用";
$lang_update_link = "现有链接信息已更新";
$lang_new_link = "新链接已添加";
$lang_new_forum_topic = "新主题已添加";
$lang_new_groupforum_topic = "已添加新话题到组论坛";
$lang_new_dropbox_file = "新文档已收到";
$lang_update_dropbox_file = "投递箱中的文件已更新";
?>