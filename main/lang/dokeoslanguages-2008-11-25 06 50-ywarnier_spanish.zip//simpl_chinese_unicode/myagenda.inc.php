<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langMyAgenda  = "日程安排";
$langToday  = "今天";
?>