<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langTask1 = "任务 1";
$langTask2 = "任务 2";
$langTask3 = "任务3";
$langTask1Desc = "任务 1 描述";
$langTask2Desc = "任务 2 描述";
$langTask3Desc = "任务 3 描述";
$langWelcome = "欢迎 ！";
$langModule = "模块";
$langUserHasPermissionNot = "用户没有权限";
$langUserHasPermission = "用户有权限";
$langLegend = "图例";
$langUserHasPermissionByRoleGroup = "用户有群组的权限";
?>