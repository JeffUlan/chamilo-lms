<?php /*
for more information: see languages.txt in the lang folder. 
*/
$lang_delete_added_resources = "删除添加的资源";
$lang_show_all_added_resources = "显示所有已添加资源";
?>