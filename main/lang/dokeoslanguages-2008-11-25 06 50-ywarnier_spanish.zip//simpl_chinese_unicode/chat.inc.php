<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langOnlineConference  = "在线会议";
$langWash  = "洗刷";
$langReset  = "重置";
$langSave  = "保存";
$langRefresh  = "刷新";
$langIsNowInYourDocDir  = "现在在你的文档工具中，<BR><B>这个文件是可见的</B>";
$langCopyFailed  = "打印失败";
$langTypeMessage  = "请输入你的消息!";
$langConfirmReset  = "真的想要删除所有消息吗？";
$langHasResetChat  = "已经重置聊天室";
$langNoOnlineConference  = "现在还没有会议... ";
$langMediaFile  = "直播音频或视频流";
$langContentFile  = "介绍";
$langListOfParticipants  = "成员列表";
$langYourPicture  = "你的图片";
$langOnlineDescription  = "会议描述";
$langOnlyCheckForImportantQuestion = "当要提出重要问题时，请选中此框！";
$langQuestion = "问题";
$langClearList = "清除列表";
$langWhiteBoard = "白板";
$langTextEditorDefault = "<H2>文字处理</H2>从微软Word中剪切和粘贴到这里然后编辑，成员将会看到你的在线修改。";
$langStreaming = "流媒体";
$langStreamURL = "流媒体链接";
$langStreamType = "流媒体类型";
$langLinkName = "链接名称";
$langLinkURL = "链接网址";
$langWelcomeToOnlineConf = "欢迎来到<B>在线会议</B>";
$langNoLinkAvailable = "没有链接可用";
$langChat_reset_by = "重置聊天室";
$langCallSent = "聊天请求已经发送，等待对方同意。";
$langChatDenied = "你的聊天请求已经被对方拒绝。";
?>