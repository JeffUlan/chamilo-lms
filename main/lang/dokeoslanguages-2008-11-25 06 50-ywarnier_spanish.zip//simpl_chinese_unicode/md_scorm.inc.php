<?php /*
for more information: see languages.txt in the lang folder. 
*/
$nameTools = "过时语言变量";
$langMdCallingTool = "学习路径 - SCORM";
$langTool = "SCORM MD 行动";
$langNotInDB = "没有数据库条目";
$langManifestSyntax = "（manifest 文件语法错误...）";
$langEmptyManifest = "（空 manifest 文件...）";
$langNoManifest = "（无 manifest 文件...）";
$langNotFolder = "不可能，它不是一个文件夹...";
$langUploadHtt = "上传 HTT 文件";
$langHttFileNotFound = "新的 HTT 文件无法打开（因为空或太大）";
$langHttOk = "新 HTT 文件已经上传";
$langHttNotOk = "上传 HTT 文件失败";
$langRemoveHtt = "删除 HTT 文件";
$langHttRmvOk = "HTT 文件已被删除";
$langHttRmvNotOk = "删除 HTT 文件失败";
$langImport = "从 manifest 创建 MDE";
$langRemove = "删除 MDE";
$langAllRemovedFor = "移去所有条目";
$langIndex = "有 PhpDig 的索引词";
$langTotalMDEs = "全部 Scorm MD 条目的数数量:";
$langMainMD = "开启主要 MDE";
$langLines = "行";
$langPlay = "执行 index.php";
$langNonePossible = "不可能执行任何 MD 行动";
$langOrElse = "选择一个 Scorm 目录或一个 Scorm 目录编号";
$langWorkWith = "在 Scorm 路径中运行";
$langSDI = "... 有 SD-id 的 Scorm 路径（清楚分开 - 或保持为空）";
$langRoot = "根";
$langSplitData = "分离 manifest 和#MDe,  如有:";
$langMffNotOk = "替换 manifest 文件失败";
$langMffOk = "已替换 manifest 文件";
$langMffFileNotFound = "新的 manifest 文件无法开启（可能是空或太大）";
$langUploadMff = "替换 manifest 文件";
?>