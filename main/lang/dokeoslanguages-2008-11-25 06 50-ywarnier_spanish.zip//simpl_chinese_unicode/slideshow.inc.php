<?php /*
for more information: see languages.txt in the lang folder. 
*/
$lang_height = "高度";
$lang_resizing_comment = "将图像的尺寸改编为下面的尺寸(用像素表示)";
$lang_width = "宽度";
$lang_resizing = "重新定义尺寸";
$lang_no_resizing_comment = "显示所有图像的原始尺寸, 没有重新定义尺寸, 如果图像大于显示器的尺寸滚动条将自动显示.";
$lang_show_thumbnails = "显示略图";
$lang_click_thumbnails = "点击略图的其中之一";
$lang_set_slideshow_options = "幻灯设置";
$lang_slideshow_options = "幻灯选项";
$lang_no_resizing = "不可重新定义尺寸(默认)";
$lang_exit_slideshow = "退出幻灯";
$lang_previous_slide = "上一张";
$lang_next_slide = "下一张";
$lang_image = "图像";
$lang_of = "的";
$lang_view_slideshow = "查看幻灯";
?>