<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langCourseProgram  = "教学大纲";
$langThisCourseDescriptionIsEmpty  = "本课程目前没有教学大纲。";
$langEditCourseProgram  = "创建和编辑课程简介";
$langInfo2Say  = "发送给用户的信息";
$langOuAutreTitre  = "标题";
$langNewBloc  = "其他内容";
$langAddCat  = "添加分类";
$langAdd  = "添加";
$langValid  = "可用的";
$langBackAndForget  = "返回和取消";
?>