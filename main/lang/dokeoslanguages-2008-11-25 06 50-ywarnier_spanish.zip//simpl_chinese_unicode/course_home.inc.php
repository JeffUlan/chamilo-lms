<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langActivate = "公开";
$langDeactivate = "隐藏";
$langInLnk  = "隐藏的工具";
$langDelLk = "确定要移除该工具吗? ";
$langEnter  = "进入";
$langCourseCreate  = "创建课程";
$langNameOfTheLink  = "链接名称";
$lang_main_categories_list                  = "主分类列表";
$langCourseAdminOnly = "教师";
$langCombinedCourse = "合并的课程";
?>