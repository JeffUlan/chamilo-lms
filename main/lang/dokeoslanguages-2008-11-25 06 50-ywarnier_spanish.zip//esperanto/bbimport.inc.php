<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langViewCourseMaterialImport  = "Rigardu al la kursa&#309;o, kia &#285;i estos importata ";
$langViewExternalLinksImport  = "Rigardu al la eksternaj ligiloj, kiaj ili estas importataj ";
$langViewForumImport  = "Rigardu al la forumoj, kiaj ili estos importataj ";
$langImportCourseMaterial  = "Importu kursmaterialon (Nigratabula modulo \"Course Material\") XX";
$langImportExternalLinks  = "Importu ligilojn (Nigratabula modulo \"Eksternal Links\") XX";
$langImportForum  = "Importu forumojn (Nigratabula modulo \"Discussion Board\") XX";
$langToolInfo  = "&#264;i-modulo importas Blackboard 5.5 -kursojn (Course Material, Discussion Board, and External Links). XX";
$langToolName = "Importado de Nigratabulaj kursoj ";
$langSelectCoursePackage = "Elektu kursaron ";
$langPackageAlreadySelected = "Vi jam elektis kursaron ";
$langFirstSelectPackage = "Unue elektu aron kaj malfermu &#285;in por povi ekimporti &#285;in.";
$langCourseToMigrate = "Importota kurso";
$langSelectPackage = "Elektu aron";
$langOpenPackageForImporting = "Malfermu &#265;i-kursaron por importi &#285;in ";
$langInformation = "Informo pri la importado ";
$langChooseImportOptions = "Elekti opciojn ";
$langCheckWhatIsImported = "Eventuale vi povas rigardi al kio estos importata anta&#365; fakte starti la importadon. ";
$langStartImporting = "Startigi la importadon ";
$langImport = "Importi ";
?>