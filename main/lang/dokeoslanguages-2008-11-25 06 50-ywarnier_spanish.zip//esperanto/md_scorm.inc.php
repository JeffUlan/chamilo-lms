<?php /*
for more information: see languages.txt in the lang folder. 
*/
$nameTools = "arkai&#285;inta lingvovariablo ";
$langMdCallingTool = "Lernpado - Scorm";
$langTool = "Scorm-MD-operacioj ";
$langNotInDB = "ne Dokeos-datumbaza elemento ";
$langManifestSyntax = "(sintaksa eraro en Manifest-dosiero ...) ";
$langEmptyManifest = "(malplena Manifest-dosiero ...) ";
$langNoManifest = "(ne Manifest-dosiero ...) ";
$langNotFolder = "ne eblas, ne estas dosierujo ...";
$langUploadHtt = "Al&#349;uti HTML-&#349;ablonon";
$langHttFileNotFound = "Nova HTML-&#349;ablono ne povas esti malfermita (malplena? tro granda?)";
$langHttOk = "La nova HTML-&#349;ablono estas al&#349;utita";
$langHttNotOk = "La al&#349;utado de la HTML-&#349;ablono fiaskis";
$langRemoveHtt = "Vi&#349;i la HTML-&#349;ablonon";
$langHttRmvOk = "HTML-&#349;ablono vi&#349;ita";
$langHttRmvNotOk = " La vi&#349;ado de la HTML-&#349;ablono fiaskis";
$langImport = "Fari MDE-jn por la Manifest-dosiero ";
$langRemove = "Forigi MDEjn";
$langAllRemovedFor = "&#264;io forigita anta&#365;  XX";
$langIndex = "Indeksvortoj kun PhpDig ";
$langTotalMDEs = "Entuta nombro da Scorm-MD-datumoj: ";
$langMainMD = "Malfermi &#265;ef-MDEn";
$langLines = "Linioj";
$langPlay = "Ludi index.php ";
$langNonePossible = "MD-operacioj ne eblas";
$langOrElse = "Elektu Scorm-dosierujon au Scorm-dosieruja id";
$langWorkWith = "Uzi Scorm-dosierujon";
$langSDI = "... Scorm-dosierujo kun SD-id (kaj disigi la Manifeston - a&#365; lasi &#285;in malplena)";
$langRoot = "radiko ";
$langSplitData = "Disigi Manifest-dosiero, kaj #MDEn, se: ";
$langMffNotOk = "La anstata&#365;igo de la Manifest-dosiero malsukcesis ";
$langMffOk = "La Manifest-dosiero estas anstata&#365;igita. ";
$langMffFileNotFound = "Nova Maifest-dosiero ne povas esti malfermata (ekz. &#265;ar malplena, tro granda)";
$langUploadMff = "Anstata&#365;igi Manifest-dosieron ";
?>