<?php /*
for more information: see languages.txt in the lang folder. 
*/
$Tools  = "Ilaro";
$langDownloadFile = "El&#349;uti la dokumenton";
$langTooBig = "Vi ne elektis el&#349;utendan dosieron a&#365; &#285;i estas tro granda. ";
$langListDeleted = "La listo estas tute forigita. ";
$langDocModif = "La dokumento estas &#349;an&#285;ita ";
$langDocAdd = "La dokumento estas aldonita ";
$langDocDel = "La dokumento estas forigita ";
$langTitleWork = "Plena titolo de la verko";
$langAuthors = "a&#365;toroj";
$langDelList = "Forigi la tutan liston ";
$langWorkDelete = "Forigu ";
$langWorkModify = "Modifi ";
$langWorkConfirmDelete = "&#264;u certe, ke vi volas vi&#349;i &#265;i-dosieron? ";
$langAllFiles = "Agadoj je &#265;iuj dosieroj ";
$lang_default_upload = "Apriora agordo pri la videbleco de al&#349;utitaj dokumentoj ";
$lang_new_visible = "Novaj dokumentoj videblas al &#265;iuj uzuloj ";
$lang_new_unvisible = "Novaj dokumentoj videblas nur al kursmastrumanto(j)";
$lang_doc_unvisible = "Via instruisto tamen preferis videbligi la dokumenton nur al kursomastrumantoj kaj tial la dokumento ne videblos al vi.";
$langDelLk = "forigi ligilon ";
$langMustBeRegisteredUser = "Vi registri&#285;u je &#265;i-kurso por rajti publikigi verkon. ";
$langListDel = "Forigu liston ";
$langNameDir = "renomi dosierujon ";
$langFileExists = "dosiero jam ekzistas ";
$langDirCr = "krei dosierujon";
$langCurrentDir = "aktuala dosierujo ";
$UploadADocument = "al&#349;uti dokumenton";
$EditToolOptions = "&#349;an&#285;i modulajn opciojn ";
$DocumentDeleted = "La dokumento forigitas.";
$SendMailBody = "Uzulo enpo&#349;tigis dokumenton en la publikigilon de via kurso";
$DirDelete = "Forigi dosierujon";
$ValidateChanges = "Validigi &#349;an&#285;ojn";
$FolderUpdated = "Dosierujo &#285;isdatigitas.";
?>