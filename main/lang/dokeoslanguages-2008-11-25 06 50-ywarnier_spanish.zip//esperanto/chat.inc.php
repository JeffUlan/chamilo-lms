<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langOnlineConference  = "Interreta konferenco";
$langWash  = "Vi&#349;i ";
$langReset  = "Restartigi";
$langSave  = "Konservi ";
$langRefresh  = "Refre&#349;igi ";
$langIsNowInYourDocDir  = "estas nun en via dokument-ero. <br><B>Atentu, la dosiero nun alireblas por &#265;iu</B> ";
$langCopyFailed  = "La kopiado de la dosiero malsukcesis... ";
$langTypeMessage  = "Bonvolu tajpi tekston! ";
$langConfirmReset  = "&#264;u certe, ke vi volas forigi &#265;iujn mesa&#285;ojn? ";
$langHasResetChat  = "re&#349;argis la babiladon ";
$langNoOnlineConference  = "&#264;i-momente ne estas konferenco ";
$langMediaFile  = "rekta a&#365;d- a&#365; vidstriado ";
$langContentFile  = "Prezenta&#309;o ";
$langListOfParticipants  = "Listo de partoprenantoj ";
$langYourPicture  = "Via foto ";
$langOnlineDescription  = "Priskribo de la konferenco ";
$langOnlyCheckForImportantQuestion = "Bonvolu marki &#265;i-opcion nur se vi starigas gravan demandon.";
$langQuestion = "demando ";
$langClearList = "Vi&#349;i ";
$langWhiteBoard = "Tabulo ";
$langTextEditorDefault = "<h2>Tekstprilaborilo</h2>  Aldonu &#265;i tie tekston, bildojn, ligilojn ... Partoprenantoj de tiu &#265;i rekta konferenco senpere vidas viajn &#349;an&#285;ojn. ";
$langStreaming = "Datumstriado XX";
$langStreamURL = "Datumstria URL  XX";
$langStreamType = "Datumstria tipo XX";
$langLinkName = "Nomo ";
$langLinkURL = "URL ";
$langWelcomeToOnlineConf = "Bonvenon &#265;e tiu &#265;i <b>rekta konferenco</b> ";
$langNoLinkAvailable = "Ne disponeblas ligilo ";
$langChat_reset_by = "re&#349;argi babiladon ";
$OrFile = "A&#365; dosiero ";
$langCallSent = "Babilpeto sendita. Atendu la konsenton de via partnero. ";
$langChatDenied = "Via peto estas ignorata de via partnero. ";
?>