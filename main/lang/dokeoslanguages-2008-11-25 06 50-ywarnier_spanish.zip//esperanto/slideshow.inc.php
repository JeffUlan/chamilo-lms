<?php /*
for more information: see languages.txt in the lang folder. 
*/
$lang_height = "Alto ";
$lang_resizing_comment = "Adapti la grandon de la bildo al jenaj dimensioj (en rastrumeroj)";
$lang_width = "Lar&#285;o ";
$lang_resizing = "ADAPTI DIMENSIOJN ";
$lang_no_resizing_comment = "Montru &#265;iujn bildojn la&#365; ilia originala grando. La bildoj ne estos pligrandigitaj a&#365; malpligrandigitaj. &#348;oviloj aperos, se la bildo pli grandas ol via ekrano.";
$lang_show_thumbnails = "Montru miniaturojn ";
$lang_click_thumbnails = "Alklaku miniaturon";
$lang_set_slideshow_options = "Agordoj de la lumbilda prezentado";
$lang_slideshow_options = "Opcioj de la lumbilda prezentado";
$lang_no_resizing = "NE ADAPTI DIMENSIOJN (elektu apriorajn) ";
$lang_exit_slideshow = "Fini prezentadon";
$SlideShow = "Lumbilda prezentado";
$lang_previous_slide = "Al anta&#365;a bildo ";
$lang_next_slide = "Al sekvanta bildo ";
$lang_image = "Bildo ";
$lang_of = "de ";
$lang_view_slideshow = "Montri prezentadon";
?>