<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langLinkSite = "Ligilo al retejo ";
$langSubTitle = "Aldonas ligilon al via kursa hejmpa&#285;o. ";
$langAddPage            = "Aldoni pa&#285;on ";
$langSendPage           = "Aldonenda pa&#285;o ";
$langCouldNot           = "Dosiero ne povis esti sendata ";
$langOkSentPage         = "Via pa&#285;o estas aldonita. <p>&#284;i estas nun alirebla per la <a href=\\\"../../\".$_course[\'path\'].\"/index.php\\\">kursa hejmpa&#285;o</a>.";
$langOkSentLink         = "La ligilo estas aldonita. &#284;i estas nun alirebla per <a href=\\\"\".api_get_path(WEB_COURSE_PATH). $_course[\'path\'] . \"/index.php\\\">kursa hejmpa&#285;o</a>";
$langTooBig             = "Vi ne elektis sendotan dosieron a&#365; la dosiero estas tro granda. ";
$langExplanation        = "La pa&#285;o estu html-formata, ekzemple \"mia_pagxo.html\"). &#284;i estas aldonota al la kursa hejmpa&#285;o. Por formatoj aliaj ol HTML (kiaj PDF, Word, Power Point, Video, ktp.) uzu <a href=../document/document.php>Dokumentan modulon</a>.";
$langPgTitle            = "Pa&#285;a titolo ";
$langNoLinkURL          = "Bonvolu doni al adreson (URL) de la ligilo. ";
$langLinkTarget = "Celo de la ligilo ";
$langSameWindow = "En la sama fenestro ";
$langNewWindow = "En nova fenestro ";
$langAdded = "La ligilo estas aldonita ";
$langAddLink = "Aldoni ligilon ";
$langNoLinkName = "Bonvolu atribui nomon al la ligilo. ";
$langEditLink = "&#348;an&#285;i kursan ligilon en hejmpa&#285;o ";
$langChangePress = "&#348;an&#285;u kaj klaku sur \'en ordo\'";
$langLinkChanged = "Kurs&#265;efpa&#285;a ligilo &#349;an&#285;ita. Uzu la supran paneran menuon por reiri al la &#265;efpa&#285;o. ";
$NoLinkName = "Ligila nomo mankas";
$NoLinkURL = "Ne ligila URL";
$LinkChanged = "Ligilo &#349;an&#285;ita";
$OkSentLink = "La ligilo estas sendita";
?>