<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langLineNumber = "Lininumero ";
$langLine = "linio";
$langLines = "linioj";
$langLineOrLines = "linio(j) ";
$langMoveUp = "Supren";
$langMoveDown = "Suben";
$langAddNewHeading = "Aldoni novan surskribon ";
$langCourseAdministratorOnly = "Nur por la kursestro";
$langDefineHeadings = "Difini surskribojn ";
$langBackToUsersList = "Reiri al la uzula listo ";
$langTracking = "Spuri ";
$langCourseManager = "Kursestro";
$langModRight = "&#348;an&#285;i mastrumrajtojn de ";
$langNoAdmin = "havas ekde nun <b>neniun</b> mastrumrajton de &#265;i-pa&#285;o ";
$langAllAdmin = "havas ekde nun <b>&#265;iujn</b> mastrumrajtojn de &#265;i-pa&#285;o ";
$langModRole = "Modifi rolon de ";
$langRole = "Rolo (fakultative) ";
$langIsNow = "estas ekde nun ";
$langInC = "en &#265;i-kurso ";
$langFilled = "Vi ne plenigis &#265;iujn kampojn.";
$langUserNo = "La de vi elektita uzula nomo ";
$langTaken = "estas jam uzata. Elektu alian. ";
$langTutor = "Kondukanto (grupa) ";
$langUnreg = "Malali&#285;i ";
$langGroupUserManagement = "Grupa mastrumado ";
$langUserInfo = "uzulaj informoj";
$langUnregister = "Malali&#285;i";
$langAddAUser = "aldoni uzulojn";
?>