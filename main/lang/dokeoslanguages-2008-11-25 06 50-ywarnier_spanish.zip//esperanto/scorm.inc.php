<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langScormVersion = "versio ";
$langScormRestarted = "Ciuj lecionoj estas nun malkompletaj. ";
$langScormNoNext = "Jen la lasta leciono. ";
$langScormNoPrev = "Jen la unua leciono. ";
$langScormTime = "Tempo ";
$langScormNoOrder = "Ne estas difinita ordo; vi povas musklaki sur ajna leciono. ";
$langScormScore = "Poentaro ";
$langScormLessonTitle = "Leciona tiolo ";
$langScormStatus = "Statuso ";
$langScormToEnter = "Por partopreni ";
$langScormFirstNeedTo = "vi unue realigu la sekvantan lecionon: ";
$langScormThisStatus = "&#264;i-leciono estas nun ";
$langScormClose = "Fini ";
$langScormRestart = "Restarti ";
$langScormCompstatus = "Kompletigita ";
$langScormIncomplete = "Ne kompleta ";
$langScormPassed = "Sukcesis ";
$langScormFailed = "Malsukcesis ";
$langScormPrevious = "Anta&#365;a ";
$langScormNext = "Sekvanta ";
$langScormTitle = "Dokeos-Scorm-ludilo ";
$langScormMystatus = "Mia statuso ";
$langScormNoItems = "&#264;i-enhavo enhavas neniun elementon. ";
$langScormNoStatus = "Ne statuso por &#265;i-enhavo ";
$langScormLoggedout = "adia&#365;inta el Scorm-tuta&#309;o ";
$langScormCloseWindow = "Fermi fenestron ";
$ScormBrowsed = "Vizitita";
$langScormExitFullScreen = "Reiri al normala ekrano ";
$langScormFullScreen = "Plena ekrano ";
$langScormNotAttempted = "Ne provita ";
$langCharset = "Tiparo";
$langLocal = "Loka";
$langRemote = "Fora";
$langAutodetect = "A&#365;tomate trovi";
$langAccomplishedStepsTotal = "Nombro da finitaj pa&#349;oj";
$langUnknown = "Nekonata";
?>