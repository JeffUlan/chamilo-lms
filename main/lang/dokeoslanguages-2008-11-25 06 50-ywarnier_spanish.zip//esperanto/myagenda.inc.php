<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langMyAgenda  = "Mia agendo";
$langToday  = "hodia&#365;";
?>