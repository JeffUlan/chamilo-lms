<?php /*
for more information: see languages.txt in the lang folder. 
*/
$lang_new_item = "nova elemento aldonita ";
$lang_title_notification = "Ekde via anta&#365;a vizito ";
$lang_update_agenda = "ekzistanta agendero adaptita ";
$lang_new_agenda = "nova agendero aldonita ";
$lang_update_announcements = "Ekzistanta publikeja anonco modifita ";
$lang_new_announcements = "nova publikeja anonco aldonita ";
$lang_new_document = "nova(j) dokumento(j) aldonita(j) ";
$lang_new_exercise = "nova ekzerco disponebligita ";
$lang_update_link = "ekzistanta ligila informo adaptita ";
$lang_new_link = "nova ligilo aldonita ";
$lang_new_forum_topic = "nova temo aldonita ";
$lang_new_groupforum_topic = "nova temo aldonita al grupa forumo ";
$lang_new_dropbox_file = "Nova dosiero ricevita ";
$lang_update_dropbox_file = "dosiero en la studenta publika&#309;o estas &#349;an&#285;ita ";
?>