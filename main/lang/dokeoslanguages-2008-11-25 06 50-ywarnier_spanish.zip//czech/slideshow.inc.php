<?php /*
for more information: see languages.txt in the lang folder. 
*/
$lang_height = "V��ka";
$lang_resizing_comment = "zm&#283;nit velikost obr�zku na nasleduj�c� rozm&#283;ry (v pixlech)";
$lang_width = "��&#345;ka";
$lang_resizing = "ZM&#282;NIT VELIKOST";
$lang_no_resizing_comment = "Zobraz v�echny obr�zky v jejich p&#367;vodn�m rozm&#283;ru. Nenastane zm&#283;na velikosti. Rolovac� li�ty se v�m zobraz� automaticky, kdy� bude obr�zek v&#283;t�� ne� je rozm&#283;r va�� obrazovky.";
$lang_show_thumbnails = "Zobraz Miniatury";
$lang_click_thumbnails = "Klikn&#283;te na jednu z miniatur";
$lang_set_slideshow_options = "Nastavit mo�nosti prezentace";
$lang_slideshow_options = "Mo�nosti prezentace";
$lang_no_resizing = "NEM&#282;NIT VELIKOST (p&#345;ednastaven�)";
$lang_exit_slideshow = "Ukon&#269;i prezentaci";
$SlideShow = "Prezentace";
$lang_previous_slide = "P&#345;edchoz� sn�mek";
$lang_next_slide = "Dal�� sn�mek";
$lang_image = "Obr�zek";
$lang_of = "z";
$lang_view_slideshow = "Zobraz prezentaci";
?>