<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langOnlineConference  = "Konference";
$langWash  = "Vy&#269;istit";
$langReset  = "Resetovat";
$langSave  = "Ulo�it";
$langRefresh  = "Aktualizovat";
$langIsNowInYourDocDir  = "je nyn� ulo�en� ve Va�� slo�ce dokument&#367;. <br><B>Tento soubor je viditeln�</B>";
$langCopyFailed  = "Tisk se nezda&#345;il";
$langTypeMessage  = "Pros�m napi�te Va�i spr�vu!";
$langConfirmReset  = "Opravdu chcete smazat v�echny spr�vy?";
$langHasResetChat  = "zresetov�n Chat";
$langNoOnlineConference  = "Moment�ln&#283; nen� ��dn� konference ...";
$langMediaFile  = "�iv� audio nebo video streaming";
$langContentFile  = "Prezentace";
$langListOfParticipants  = "Seznam �&#269;astn�k&#367;";
$langYourPicture  = "Va�e foto";
$langOnlineDescription  = "Popis konference (On-line)";
$langOnlyCheckForImportantQuestion = "Pros�m za�krtn&#283;te pol�&#269;ko jenom v p&#345;�pad&#283; d&#367;le�it� ot�zky !";
$langQuestion = "ot�zka";
$langClearList = "Vy&#269;istit seznam";
$langWhiteBoard = "Tabule na psan�";
$langTextEditorDefault = "<h2>Textov� editor</h2>Z programu MS-Word� zde m&#367;�ete vkl�dat a vyjmout text, a pak upravovat. �&#269;astn�ci uvid� va�e �pravy na&#378;ivo.";
$langStreaming = "P&#345;enos (streaming)";
$langStreamURL = "Stream-URL";
$langStreamType = "Typ streamingu";
$langLinkName = "N�zev odkazu (linku)";
$langLinkURL = "URL odkaz (link)";
$langWelcomeToOnlineConf = "V�tejte v <b>Online Konferenci</b>";
$langNoLinkAvailable = "Nen� odkaz (link)";
$langChat_reset_by = "reset chatu";
$OrFile = "Nebo soubor";
$langCallSent = "V�e pozv�n� na Chat hovor bylo posl�no, nyn� &#269;ek�m na potvrzen� od va�eho partnera.";
$langChatDenied = "Volan� zam�tnul V� hovor.";
?>