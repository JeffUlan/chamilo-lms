<?php /*
for more information: see languages.txt in the lang folder. 
*/
$MyTasks = "Moje �koly";
$FavoriteBlogs = "Moje obl�ben� blog-y";
$Navigation = "Navigace";
$TopTen = "Top ten Blogy";
$Subtitle = "Podnadpis";
$ThisBlog = "Tento blog";
$NewPost = "Nov� &#269;l�nek";
$TaskManager = "Spr�va �kol&#367;";
$langTask1 = "�loha 1";
$langTask2 = "�loha 2";
$langTask3 = "�loha 3";
$langTask1Desc = "�loha 1 - popis";
$langTask2Desc = "�loha 2 - popis";
$langTask3Desc = "�loha 3 - popis";
$blog_management = "Blog management";
$langWelcome = "V�tejte !";
$langModule = "Modul";
$langUserHasPermissionNot = "U�ivatel nem� pr�va";
$langUserHasPermission = "U�ivatel m� pr�va";
$langLegend = "Legenda";
$langUserHasPermissionByRoleGroup = "U�ivatel m� pr�va v jeho skupin&#283;";
?>