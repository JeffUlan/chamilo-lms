<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langScormBuilder = "Vytv�&#345;en� u&#269;ebn� osnovy - tvorba kurzu ve form�tu Scorm";
?>