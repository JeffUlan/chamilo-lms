<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langViewCourseMaterialImport  = "Zobraz materi�l kurzu tak jak bude naimportov�n";
$langViewExternalLinksImport  = "Zobraz extern� odkazy tak jak budou naimportov�ny";
$langViewForumImport  = "Zobraz f�rum tak jak bude importov�no";
$langImportCourseMaterial  = "Import materi�lu kurzu (Blackboard n�stroj \"Materi�l kurzu\")";
$langImportExternalLinks  = "Import odkaz&#367; (Blackboard n�stroj \"Extern� Odkazy\")";
$langImportForum  = "Importovat f�rumy (Blackboard n�stroj \"Diskusn� f�ra/board\")";
$langToolInfo  = "Tento n�stroj importuje kurzy z Blackboard 5.5 (Materi�l kurzu, Diskusn� f�ra, a Extern� Odkazy)";
$langToolName = "Importuj kurzy z Blackboard-u";
$langSelectCoursePackage = "Vyberte bal�&#269;ek kurzu";
$langPackageAlreadySelected = "M�te ji� vybranej bal�&#269;ek";
$langFirstSelectPackage = "P&#345;edt�m ne� budete pokra&#269;ovat v importov�n�, mus�te nejd&#345;�ve vybrat bal�&#269;ek a otev&#345;�t ho.";
$langCourseToMigrate = "St&#283;hovat kurz";
$langSelectPackage = "Vyberte bal�&#269;ek";
$langOpenPackageForImporting = "Otev&#345;�t tento bal�&#269;ek pro importov�n�";
$langInformation = "Informace o pr&#367;b&#283;hu importov�n�";
$langChooseImportOptions = "Zvolte mo�nosti Va�eho importu";
$langCheckWhatIsImported = "P&#345;edt�m ne� za&#269;ne proces importov�n�, m&#367;�ete se pod�vat na to co bude importov�no";
$langStartImporting = "Start importov�n�";
$langImport = "Import";
?>