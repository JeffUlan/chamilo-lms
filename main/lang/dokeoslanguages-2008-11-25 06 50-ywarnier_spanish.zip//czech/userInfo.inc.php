<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langLineNumber = "&#268;�slo &#345;�dku";
$langLine = "&#345;�dek";
$langLines = "&#345;�dky";
$langLineOrLines = "&#345;�dek(ky)";
$langMoveUp = "Posunout nahoru";
$langMoveDown = "Posunout dol&#367;";
$langAddNewHeading = "P&#345;idat nov� nadpis";
$langCourseAdministratorOnly = "Pouze pro u&#269;itele";
$langDefineHeadings = "Definuj nadpisy";
$langBackToUsersList = "Zp&#283;t na seznam u�ivatel&#367;";
$langTracking = "Sledov�n�";
$langCourseManager = "U&#269;itel";
$langModRight = "zm&#283;na pr�v na";
$langNoAdmin = "od te&#271; nem� <b>��dn�</b> pr�va na t�to str�nce";
$langAllAdmin = "od te&#271; m� <b>ve�ker�</b> pr�va na t�to str�nce";
$langModRole = "Zm&#283;na role na";
$langRole = "Role";
$langIsNow = "je od te&#271;";
$langInC = "v tomto kurzu";
$langFilled = "Ne v�echny pole byli vypln&#283;n�";
$langUserNo = "&#268;�slo u�ivatele";
$langTaken = "je ji� pou��v�no. Zvolte pros�m jin�";
$langTutor = "Tutor (studijn� vedouc�)";
$langUnreg = "Odhl�sit";
$langGroupUserManagement = "Spr�va skupin";
$langUserInfo = "informace o u�ivateli";
$langUnregister = "Neregistrovan�";
$langAddAUser = "P&#345;idat u�ivatele";
?>