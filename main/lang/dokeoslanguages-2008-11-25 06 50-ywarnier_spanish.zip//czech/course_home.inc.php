<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langActivate = "Uk�zat";
$langDeactivate = "Skr�t";
$langInLnk  = "Skryt� n�stroje a odkazy";
$langDelLk = "Opravdu chcete smazat tenhle odkaz?";
$langEnter  = "Vstoupit";
$langCourseCreate  = "Vytvo&#345;it webovou str�nku kurzu";
$langNameOfTheLink  = "Jm�no odkazu";
$lang_main_categories_list                  = "Seznam hlavn�ch kategori�";
$langCourseAdminOnly = "Jen pro u&#269;itele";
$PlatformAdminOnly = "Jen pro platformov� Administr�tory";
$langCombinedCourse = "Kombinovan� kurz";
$ToolIsNowVisible = "N�stroj je nyn� viditeln�.";
$ToolIsNowHidden = "N�stroj je nyn� neviditeln�.";
$EditLink = "Editovat odkaz";
$Blog_management = "Administrace Blog&#367;";
$Forum = "F�ra";
$Course_maintenance = "Spravovat kurz";
$TOOL_SURVEY = "Pr&#367;zkum";
$GreyIcons = "Sada n�stroj&#367;";
$Interaction = "Interakce";
$Authoring = "Auto&#345;i";
$Administration = "Administrace";
?>