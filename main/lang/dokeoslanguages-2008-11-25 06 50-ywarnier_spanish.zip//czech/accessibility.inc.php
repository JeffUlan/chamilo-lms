<?php /*
for more information: see languages.txt in the lang folder. 
*/
$test = "test";
$WCAGImage = "Obr�zek";
$WCAGLabel = "N�zev obr�zku";
$WCAGLink = "Link";
$WCAGLinkLabel = "N�zev link-u";
$errorNoLabel = "Chyb� n�zev na obr�zku.";
$WCAGEditor = "Editor WCAG";
$WCAGGoMenu = "Jdi do menu";
$WCAGGoContent = "Jdi na obsah";
?>