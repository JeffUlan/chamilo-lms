<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langCourseProgram  = "Popis kurzu";
$langThisCourseDescriptionIsEmpty  = "Tento kurz moment�ln&#283; nen� popsan�.";
$langEditCourseProgram  = "Vytvo&#345;it a editovat popis kurzu";
$QuestionPlan  = "Ot�zka pro vedouc�ho";
$langInfo2Say  = "Informace pro studenty";
$langOuAutreTitre  = "N�zev";
$langNewBloc  = "Dal��";
$langAddCat  = "p&#345;idat kategorii";
$langAdd  = "P&#345;idat";
$langValid  = "Platn�";
$langBackAndForget  = "Zp&#283;t a zapomenout";
?>