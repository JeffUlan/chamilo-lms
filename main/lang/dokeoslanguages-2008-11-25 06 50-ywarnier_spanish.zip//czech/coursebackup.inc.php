<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langSelectOptionForBackup = "Pros�m zvolte mo�osti z�lohov�n�.";
$langLetMeSelectItems = "Dovolte mi zvolit &#269;�sti kurzu";
$langCreateFullBackup = "Vytvo&#345;it kompletn� z�lohu tohoto kurzu";
$langCreateBackup = "vytvo&#345;it z�lohu";
$langBackupCreated  = "Byla vytvo&#345;ena z�loha tohoto kurzu. P&#345;enos d�t za&#269;ne za okam�ik. Jest-li V� p&#345;enos nefunguje, klikn&#283;te na nasleduj�ci odkaz";
$langSelectBackupFile = "vyberte soubor se z�lohou";
$langImportBackup = "Importuj z�lohu";
$langImportFullBackup = "Importuj kompletn� z�lohu";
$langImportFinished = "Import dokon&#269;en";
$langEvents = "Ud�losti";
$langAnnouncements = "Ozn�men�";
$langDocuments  = "Dokumenty";
$langTests = "Testy";
$langLearnpaths = "Learn-paths (sp&#367;sob u&#269;en�)";
$langCopyCourse = "Kop�rovat kurz";
$langSelectItemsToCopy = "Zvolte polo�ky pro kop�rov�n�";
$langCopyFinished = "Kop�rov�n� je dokon&#269;eno";
$langFullRecycle = "Kompletn� recyklace";
$langRecycleCourse = "Recyklace kurzu";
$langRecycleFinished = "Recyklace je dokon&#269;ena";
$langRecycleWarning = "Varov�n�: pou�it�m t�to funkce sma�ete n&#283;kter� &#269;�sti va�eho kurzu, a to nen�vratn&#283;. Proto V�m doporu&#269;ujeme ud&#283;lat <a href=\"create_backup.php\">z�lohu</a> p&#345;ed pou�it�m tohoto recyklovac�ho n�stroje.";
$langSameFilename = "Co ud&#283;lat kdy� importov�n� soubory maj� stejn� jm�no jako existuj�c� soubory?";
$langSameFilenameSkip = "P&#345;esko&#269;it soubory se stejn�m jm�nem";
$langSameFilenameRename = "P&#345;ejmenovat soubor (nap&#345;. Soubor.pdf se st�va Soubor_1.pdf)";
$langSameFilenameOverwrite = "P&#345;epsat soubor";
$langSelectDestinationCourse = "Zvolte c�lov� kurz";
$langFullCopy  = "Kop�rovat v�echno";
$langCourseDescription = "Popis kurzu";
$langNoResourcesToBackup = "Nejsou zdroje pro z�lohov�n�";
$langNoResourcesInBackupFile = "Nejsou zdroje v souboru z�lohy";
$langSelectResources = "Vybrat zdroje";
$langNoResourcesToRecycles = "Nejsou zdroje pro recyklaci";
$langIncludeQuestionPool = "Zhrnout do sb�rky ot�zek";
$langLocalFile = "lok�ln� soubor";
$langServerFile = "soubor na serveru";
$langNoBackupsAvailable = "nen� p&#345;�stupn� ��dn� z�loha";
$langNoDestinationCoursesAvailable = "��dn� c�lov� kurz";
$langBackup = "Z�loha";
$langImportBackupInfo = "Import z�lohy. Budete schopni nahr�t soubor z va�eho lok�ln�ho disku nebo m&#367;�ete pou��t z�lohu dostupnou na serveru.";
$langCreateBackupInfo = "Vytvo&#345;it z�lohu tohoto kurzu. M&#367;�ete zvolit obsah kurzu a vlo�it ho z�lohovac�ho souboru.";
$ToolIntro = "P&#345;edstaven� n�stroje";
?>