<?php /*
for more information: see languages.txt in the lang folder. 
*/
$Inbox  = "Vstupn� schr�nka (Inbox)";
$Messages = "Zpr�vy";
$SendMessage = "Poslat spr�vu";
$NewMessage = "Nov� spr�va";
$ComposeMessage = "Napsat spr�vu";
$DeleteSelectedMessages = "Smazat vybran� spr�vy";
$SelectAll = "Ozna&#269;it v�echno";
$DeselectAll  = "Zru�it v�echno";
$ReplyToMessage = "Odpov&#283;d&#283;t";
$BackToInbox = "Zp&#283;t do vstupn� schr�nky";
$MessageSentTo = "Zpr�va byla odesl�na na";
$SendMessageTo = "Odeslat na";
$Myself = "mn&#283;";
$From = "Od";
$To = "Komu";
$Date = "Datum";
$InvalidMessageId = "Neplatn� ID spr�vy pro odeslan�.";
$ErrorSendingMessage = "P&#345;i pokusu o zasl�n� spr�vy nastala chyba.";
$SureYouWantToDeleteSelectedMessages = "Opravdu chcete smazat vybran� spr�vy?";
?>