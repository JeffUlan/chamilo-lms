<?php /*
for more information: see languages.txt in the lang folder. 
*/
$GeneralDescription = "Descrici�n xeral";
$GeneralDescriptionQuestions = "�Cal � o papel e funci�n do curso no programa ? �Requ�rense actividades previas? �Que relaci�n ten este curso con outros ?";
$GeneralDescriptionInformation = "Descrici�n do curso (n�mero de horas, c�digo, lugar onde se desenvolve...). Profesor (nome, apelidos, despacho, tel�fono, e-mail...).";
$Objectives = "Obxectivos";
$ObjectivesInformation = "Presentaci�n dos obxectivos globais e espec�ficos do curso";
$ObjectivesQuestions = "�Que quere que os estudiantes saiban facer � finalizar o curso? �Que obxectivos ir�n acadando durante o mesmo? ";
$Topics = "Contidos";
$TopicsInformation = "Lista de contidos do curso. Importancia de cada contido. Nivel de dificultade. Estrutura e interdependencia entre os seus apartados.";
$TopicsQuestions = "�Cal ser� o desenvolvemento do curso? �A que deben prestar especial atenci�n os estudantes? �Hai problemas identificados na comprensi�n dalg�ns cap�tulos? �C�nto debe adicarse a cada parte do curso?";
$Methodology = "Metodolox�a";
$MethodologyQuestions = "�Que m�todos e actividades axudar�n a acadar os obxectivos do curso? �Cal � o calendario?";
$MethodologyInformation = "Presentaci�n das actividades (conferencias, disertaci�ns, investigaci�ns en grupo, laboratorios...).";
$CourseMaterial = "Materiais";
$CourseMaterialQuestions = "�Existe unha gu�a do curso, unha colecci�n de documentos, unha bibliograf�a, unha lista de ligaz�ns de Internet ?";
$CourseMaterialInformation = "Breve descripci�n dos materiais do curso.";
$HumanAndTechnicalResources = "Recursos humanos e t�cnicos";
$HumanAndTechnicalResourcesQuestions = "�Disp�n de profesores, titores, servicio de asistencia t�cnica, aistentes sociais, salas de ordenadores?";
$HumanAndTechnicalResourcesInformation = "Descrici�n breve das persoas de contacto e dos recursos t�cnicos dispo�ibles.";
$Assessment  = "Avaliaci�n";
$AssessmentQuestions = "�Como se van avaliar os estudantes? �Cales son as estratexias para que dominen a materia?";
$AssessmentInformation = "Exemplos das preguntas do exame. Criterios de avaliaci�n. Pistas e trucos.";
?>