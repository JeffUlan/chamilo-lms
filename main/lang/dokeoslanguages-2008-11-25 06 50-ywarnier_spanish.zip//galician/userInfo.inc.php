<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langLineNumber = "N�mero de li�as";
$langLine = "li�a";
$langLines = "li�as";
$langLineOrLines = "li�a(s)";
$langMoveUp = "Subir";
$langMoveDown = "Baixar";
$langAddNewHeading = "Engadir novo encabezado";
$langCourseAdministratorOnly = "S� o administrador do curso";
$langDefineHeadings = "Definir encabezados";
$langBackToUsersList = "Voltar &aacute lista de usuarios";
$langTracking = "Seguemento";
$langCourseManager = "Profesor";
$langModRight = "cambiar os dereitos de";
$langNoAdmin = "desde agora non ten dereito de administraci�n neste sitio";
$langAllAdmin = "agora ten todos os dereitos de administraci�n sobre esta p�xina";
$langModRole = "Cambiar o rol de";
$langRole = "Rol/Estatus";
$langIsNow = "agora est� arriba";
$langInC = "neste curso";
$langFilled = "Alg�ns campos est�n incompletos";
$langUserNo = "Usuario N�";
$langTaken = "xa est� en uso. Por favor, seleccione un diferente";
$langTutor = "Titor";
$langUnreg = "Anular inscrici�n";
$langGroupUserManagement = "Xesti�n de grupos";
$langUserInfo = "Informaci�n do usuario";
$langUnregister = "Sen rexistrar";
$langAddAUser = "Engadir usuarios";
$UsersUnsubscribed = "Os usuarios seleccionados foron dados de baixa do curso";
$ThisStudentIsSubscribeThroughASession = "Este estudante est� suscrito a este curso mediante unha sesi�n. Vostede non pode editar as s�as informaci�ns";
?>