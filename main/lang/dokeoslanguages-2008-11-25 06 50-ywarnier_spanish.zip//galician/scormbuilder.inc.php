<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langScormBuilder = "Construtor de itinerarios - Construtor de cursos con formato Scorm";
?>