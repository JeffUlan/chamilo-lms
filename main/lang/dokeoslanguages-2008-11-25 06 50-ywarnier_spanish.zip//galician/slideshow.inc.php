<?php /*
for more information: see languages.txt in the lang folder. 
*/
$lang_height = "Alto";
$lang_resizing_comment = "redimensionar a imaxe co seguinte tama�o (en pixeles)";
$lang_width = "Ancho";
$lang_resizing = "Redimensionar";
$lang_no_resizing_comment = "Mostrar todas as imaxes no tama�o orixinal. Non se modificou o tama�o. As barras de desprazamento aparecer�n se a imaxe  e m�s grande c� tama�o do monitor.";
$lang_show_thumbnails = "Mostrar miniaturas";
$lang_click_thumbnails = "Clica nunha das miniaturas";
$lang_set_slideshow_options = "Opci�ns da presentaci�n";
$lang_slideshow_options = "Opci�ns da presentaci�n";
$lang_no_resizing = "Non redimensionado (por defecto)";
$lang_exit_slideshow = "Sa�r da presentaci�n";
$SlideShow = "Presentaci�n";
$lang_previous_slide = "Presentaci�n previa";
$lang_next_slide = "Pr�xima presentaci�n";
$lang_image = "Imaxe";
$lang_of = "de";
$lang_view_slideshow = "Ver presentaci�n";
?>