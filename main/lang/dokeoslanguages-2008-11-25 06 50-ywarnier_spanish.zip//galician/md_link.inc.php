<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langMdCallingTool = "Ligaz�ns";
$langMdTitle = "Nome da ligaz�n";
$langMdDescription = "Descrici�n da ligaz�n";
$langMdCoverage = "Universal";
$langMdCopyright = "Universidade de Ghent";
$nameTools = "variable de lingua obsoleta";
$langTool = "Metadatos das Ligaz�ns ";
$langNoScript = "Non se permite o script no seu navegador, por favor ignore a parte da pantalla baixo este texto, non funcionar�...";
$langLanguageTip = "a lingua na que se fixo este obxecto de aprendizaxe";
$langIdentifier = "Identificador";
$langIdentifierTip = "identificaci�n �nica para este obxecto de aprendizaxe, composta por letras, d�xitos, _-.()\'!*";
$langTitleTip = "t�tulo ou nome, e lingua dese t�tulo ou nome";
$langDescriptionTip = "descrici�n ou comentario, e lingua empregada para describir ese obxecto de aprendizaxe";
$langKeyword = "Palabras chave";
$langKeywordTip = "separar por comas (letras, d�xitos, -.)";
$langCoverage = "Categor�a";
$langCoverageTip = "nome de categor�a, p.ex. Ligaz�ns";
$langKwNote = "Se cambia a lingua da descripci�n, non engada palabras chave � vez";
$langClickKw = "Pulse nunha palabra chave na �rbore para seleccionar ou deseleccionala.";
$langKwHelp = "<br/> Pulse o bot�n \'+\' para abrir, o bot�n \'-\' para pechar, o bot�n  \'++\' para abri-los todos, o bot�n  \'--\' para pecha-los todos.<br/> <br/>Borrar todas as palabras chave pechando a �rbore e abr�ndola de novo co bot�n \'+\'.<br/> Alt-click \'+\' busca as palabras orixinais na �rbore. <br/> <br/> Alt-click selecciona unha palabra clave sen termos m�is amplos ou deselecciona unha palabra chave con termos m�is amplos.<br/> <br/> Se cambia a l�ngua de descripci�n, non engada palabras chave � vez.<br/> <br/>";
$langLocation = "URL/URI";
$langLocationTip = "pulse para abri-lo obxecto";
$langStore = "Gardar";
$langDeleteAll = "Borrar todos os metadatos";
$langConfirmDelete = "�Seguro que quere borrar *todos* os metadatos?";
$langWorkOn = "en";
$langNotInDB = "non hai categor�a Ligaz�ns";
$langManifestSyntax = "(erro de sintaxe no ficheiro de manifesto...)";
$langEmptyManifest = "(ficheiro de manifesto valeiro...)";
$langNoManifest = "(non existe ficheiro de manifesto...)";
$langNotFolder = "non son posibles, non � un directorio...";
$langContinue = "Continuar con";
$langCreate = "Crear Entradas de Metadatos (MDEs)";
$langRemove = "Eliminar Entradas de Metadatos (MDEs)";
$langAllRemovedFor = "Elimin�ronse todas as entradas para a categor�a";
$langRemainingFor = "as entradas obsoletas foron eliminadas da categor�a";
$langIndex = "Indexar palabras";
$langTotalMDEs = "N�mero total de entradas MD de ligaz�ns:";
$langMainMD = "Abrir o MDE principal";
$langOrElse = "Seleccionar unha categor�a de Ligaz�ns";
$langWarningDups = "-�os nomes de categor�a duplicados foron eliminados da lista!";
$langSLC = "Traballar coa categor�a de ligaz�ns chamada";
?>