<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langOnlineConference  = "Conferencia Online";
$langWash  = "Borrar";
$langReset  = "Actualizar";
$langSave  = "Gardar";
$langRefresh  = "Refrescar";
$langIsNowInYourDocDir  = "xa est� na s�a secci�n de documentos. <br><B>Este ficheiro � visible</B>";
$langCopyFailed  = "Fallou a impresi�n";
$langTypeMessage  = "Escribe a t�a mensaxe!";
$langConfirmReset  = "Queres borrar t�dalas mensaxes?";
$langHasResetChat  = "Borraches o chat";
$langNoOnlineConference  = "Non hai conferencias online neste intre ...";
$langMediaFile  = "Audio en tempo real ou v�deo streaming";
$langContentFile  = "Presentaci�n";
$langListOfParticipants  = "Lista de participantes";
$langYourPicture  = "A t�a foto";
$langOnlineDescription  = "Descripci&oacue;n da Conferencia Online";
$langOnlyCheckForImportantQuestion = "Por favor marca esta casilla s� para facer unha pregunta importante";
$langQuestion = "pregunta";
$langClearList = "Limpar a lista";
$langWhiteBoard = "Pizarra compartida";
$langTextEditorDefault = "<h2>Procesador de Textos</h2>Corta e pega dende Ms-Word; despois modifica. Os participantes ver�n as modificaci�ns en vivo.";
$langStreaming = "Streaming";
$langStreamURL = "URL do stream";
$langStreamType = "Tipo do stream";
$langLinkName = "Nome da ligaz�n";
$langLinkURL = "URL da ligaz�n";
$langWelcomeToOnlineConf = "Benvido � <b>Conferencia Online</b>";
$langNoLinkAvailable = "Non hai ligaz�ns dispo�ibles";
$langChat_reset_by = "reiniciar o chat";
$OrFile = "Ou ficheiro";
$langCallSent = "Enviouse a chamada para chat. Esperando a aprovaci�n da outra persoa.";
$langChatDenied = "A t�a chamada non foi admitida pola outra persoa.";
$Send = "Enviar";
$Connected = "Conectado";
?>