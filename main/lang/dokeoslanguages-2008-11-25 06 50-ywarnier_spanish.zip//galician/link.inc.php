<?php /*
for more information: see languages.txt in the lang folder. 
*/
$LinkMoved = "Moveuse a ligaz�n";
$langLinkName = "Nome da ligaz�n";
$langLinkAdd = "Engadir ligaz�n";
$langLinkAdded = "Engad�use a ligaz�n";
$langLinkMod = "Modificouse a ligaz�n";
$langLinkModded = "Modificouse a ligaz�n";
$langLinkDel = "Borrouse a ligaz�n";
$langLinkDeleted = "A ligaz�n foi eliminada";
$langLinkDelconfirm = "�Quere eliminar esta ligaz�n?";
$langAllLinksDel = "Borrar todas as ligaz�ns desta categor�a ";
$langCategoryName = "Nome da categor�a";
$langCategoryAdd = "Engadir unha categor�a";
$langCategoryAdded = "Engad�use a categor�a";
$langCategoryMod = "Modificar categor�a";
$langCategoryModded = "Modificouse a categor�a";
$langCategoryDel = "Borrar categor�a";
$langCategoryDeleted = "A categor�a e todas as ligaz�ns borr�ronse";
$langCategoryDelconfirm = "Cando borres unha categor�a, tam�n se borrar�n todas as ligaz�ns desa categoria.\\ Queres borrar a categor�a e as ligaz�ns?";
$langAllCategoryDel = "Borrar todas as categor�as e todas as ligaz�ns";
$langGiveURL = "Proporciona a ligaz�n URL";
$langGiveCategoryName = "Proporciona nome � categor�a";
$langNoCategory = "Sen categor�a";
$showall = "Expandir";
$shownone = "Contraer";
$langListDeleted = "A lista borrouse completamente";
$langAddLink = "Engadir unha ligaz�n";
$langDelList = "Borrar a lista";
$langModifyLink = "Modificar a ligaz�n";
$langCsvImport = "Importar un arquivo CSV";
$langCsvFileNotFound = "O arquivo CSV non pode abrirse (p.ex. vac�o, demasiado grande)";
$langCsvFileNoSeps = "O arquivo CSV debe usar , ou ; como separador";
$langCsvFileNoURL = "O arquivo CSV debe ter polo menos as columnas URL e t�tulo";
$langCsvFileLine1 = "... -li�a 1=";
$langCsvLinesFailed = "li�a(s) que  fallaron durante a importaci�n de links (sen URL ou t�tulo)";
$langCsvLinesOld = "ligaz�ns existentes actualizados (mesma URL e categor�a).";
$langCsvLinesNew = "nova(s) ligaz�n(s) creada(s).";
$langCsvExplain = "O arquivo deber�a ser como isto: <blockquote><pre> <b>URL</b>;categor�a;<b>t�tulo</b>;descrici�n; <b>http://www.aaa.org/...</b>;Important ligaz�ns;<b>Nome 1</b>;Descrici�n 1; <b>http://www.bbb.net/...</b>;;<b>Nome 2</b>;\"Descrici�n 2\"; </pre></blockquote> Se a URL e a categor�a son iguais a os dunha ligaz�n existente, o seu t�tulo e descripci�n ser�n actualizados. Se non, crearase unha nova ligaz�n.  <br><br> Negri�a = obligatorio. Os campos poden estar en calquera orden, e os nomes en maiuscula ou min�scula. Os campos adicionais eng�dense � descrici�n. Separador: coma ou punto e coma.  Os valores poden estar entre comi�as, pero non os nomes dos campos. Algunhas  [b]etiquetas HTML[/b] poden importarse no campo descrici�n.	";
$langLinkUpdated = "A ligaz�n foi actualizada";
$langAll_Link_Deleted = "A ligaz�n foi borrada";
$langOnHomepage = "Amosar ligaz�n na p�xina de inicio";
$langShowLinkOnHomepage = "Amosar a ligaz�n como unha icona na p�xina inicial do curso";
$langCsvImport = "Importaci�n de arquivo CSV";
$General = "Xeneral";
?>