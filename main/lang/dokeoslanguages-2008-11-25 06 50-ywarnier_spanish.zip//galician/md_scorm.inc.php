<?php /*
for more information: see languages.txt in the lang folder. 
*/
$nameTools = "variable de lingua obsoleta";
$langMdCallingTool = "Itinerario de aprendizaxe - Scorm";
$langTool = "Operaci�ns MD Scorm";
$langNotInDB = "ningunha entrada na base de datos de Dokeos";
$langManifestSyntax = "(erro de sintaxe no ficheiro de manifesto...)";
$langEmptyManifest = "(ficheiro de manifesto vac�o...)";
$langNoManifest = "(ficheiro de manifesto inexistente...)";
$langNotFolder = "non son posibles, non � un directorio...";
$langUploadHtt = "Subir arquivo HTT";
$langHttFileNotFound = "Non se puido abrir o arquivo HTT (por estar vac�o, ou moi grande...)";
$langHttOk = "Sub�use un novo arquivo HTT ";
$langHttNotOk = "Fallou o env�o do arquivo HTT";
$langRemoveHtt = "Eliminar arquivo HTT";
$langHttRmvOk = "Eliminouse o ficheiro HTT";
$langHttRmvNotOk = "O ficheiro HTT non puido ser eliminado";
$langImport = "Crear MDEs do manifesto";
$langRemove = "Eliminar MDEs";
$langAllRemovedFor = "Todas as entradas eliminadas para";
$langIndex = "Indexar palabras con PhpDig";
$langTotalMDEs = "N�mero total de entradas MD Scorm:";
$langMainMD = "Abrir MDE principal";
$langLines = "li�as";
$langPlay = "Executar index.php";
$langNonePossible = "Non son posibles as operaci�ns MD";
$langOrElse = "Seleccione un directorio Scorm ou un ID de Directorio Scorm";
$langWorkWith = "Traballar cun Directorio Scorm";
$langSDI = "...Directorio Scorm cun id de SD (e divida o manifesto ou deixelo vac�o)";
$langRoot = "ra�z";
$langSplitData = "Dividir os manifestos, e #MDe, se hai:";
$langMffNotOk = "Fallou o reemplazo do arquivo de manifesto";
$langMffOk = "O ficheiro de manifesto foi substitu�do";
$langMffFileNotFound = "Non se puido abrir o arquivo de manifesto (por estar vac�o, ou moi grande)";
$langUploadMff = "substituir o ficheiro de manifesto";
?>