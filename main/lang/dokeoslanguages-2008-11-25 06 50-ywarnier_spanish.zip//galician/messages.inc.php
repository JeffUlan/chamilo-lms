<?php /*
for more information: see languages.txt in the lang folder. 
*/
$Inbox  = "Caixa de Entrada";
$Messages = "Mensaxes";
$SendMessage = "Enviar mensaxe";
$NewMessage = "Nova mensaxe instant�nea";
$ComposeMessage = "Mensaxe instant�nea";
$DeleteSelectedMessages = "Eliminar as mensaxes seleccionadas";
$SelectAll = "Seleccionar todo";
$DeselectAll  = "Anular selecci�n";
$ReplyToMessage = "Respostar";
$BackToInbox = "Voltar � caixa de entrada";
$MessageSentTo = "Envi�uselle a mensaxe a";
$SendMessageTo = "Enviar a";
$Myself = "eu mesmo";
$From = "De";
$To = "Para";
$Date = "Data";
$InvalidMessageId = "O id da mensaxe a respostar non � v�lido.";
$ErrorSendingMessage = "Produciuse un erro ao tentar enviar a mensaxe.";
$SureYouWantToDeleteSelectedMessages = "Ten certeza de querer eliminar as mensaxes seleccionadas?";
$SelectedMessagesDeleted = "Borrouse a mensaxe seleccionada";
?>