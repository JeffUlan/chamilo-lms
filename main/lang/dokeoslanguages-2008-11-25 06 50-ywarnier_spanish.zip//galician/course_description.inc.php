<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langCourseProgram  = "Descrici�n do Curso";
$langThisCourseDescriptionIsEmpty  = "Este curso non ten descrici�n";
$langEditCourseProgram  = "Crear e editar con formularios";
$QuestionPlan  = "Cuesti�ns Clave";
$langInfo2Say  = "Informaci�n para darlles �s usuarios";
$langOuAutreTitre  = "T�tulo";
$langNewBloc  = "Outro";
$langAddCat  = "Engadir categor�a";
$langAdd  = "engadir";
$langValid  = "Validar";
$langBackAndForget  = "Volver e descartar";
$CourseDescriptionUpdated = "Actualizouse a descrici�n do curso";
$CourseDescriptionDeleted = "Eliminouse a descrici�n do curso";
$CourseDescriptionIntro = "Para crear a descrici�n dun curso, clique nunha cabeceira e encha o campo asociado.<br><br>Prema sobre De acordo e encha outra cabeceira.";
?>