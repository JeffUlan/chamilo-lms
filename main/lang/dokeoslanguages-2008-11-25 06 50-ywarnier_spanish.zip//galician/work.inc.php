<?php /*
for more information: see languages.txt in the lang folder. 
*/
$Tools  = "Ferramentas";
$langDownloadFile = "Enviar o documento";
$langTooBig = "Non elexiu o ficheiro a enviar ou o ficheiro � demasiado grande.";
$langListDeleted = "Borrouse completamente a lista";
$langDocModif = "Modificouse o documento";
$langDocAdd = "Engad�use o documento";
$langDocDel = "Borrouse o traballo";
$langTitleWork = "T�tulo do traballo";
$langAuthors = "Autores";
$langDelList = "Borrar completamente a lista";
$langWorkDelete = "Borrar";
$langWorkModify = "Modificar";
$langWorkConfirmDelete = "Realmente queres borrar este documento";
$langAllFiles = "Todos os ficheiros";
$lang_default_upload = "Configuraci�n de visibilidade establecida por defecto para os novos documentos";
$lang_new_visible = "Os novos documentos est�n visibles  para todos os usuarios";
$lang_new_unvisible = "Os novos documentos est�n s� visibles para o profesor(es)";
$lang_doc_unvisible = "Este ficheiro s� � visible para o/s profesor/es deste curso e, polo tanto, non ser� vis�ble para ti.";
$langDelLk = "Borrar ligaz�n";
$langMustBeRegisteredUser = "S� os usuarios rexistrados no curso poden publicar documentos.";
$langListDel = "Borrar lista";
$langNameDir = "Renomear directorio";
$langFileExists = "O arquivo xa exist�a con anterioridade";
$langDirCr = "Crear un directorio";
$langCurrentDir = "directorio actual";
$UploadADocument = "Subir documento";
$EditToolOptions = "Editar opci�ns da ferramenta";
$DocumentDeleted = "Documento borrado";
$SendMailBody = "Un usuario publicou un documento na ferramenta traballos do seu curso.";
$DirDelete = "Borrar o directorio";
$ValidateChanges = "Confirmar os cambios";
$FolderUpdated = "Cartafol actualizado";
?>