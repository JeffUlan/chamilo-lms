<?php /*
for more information: see languages.txt in the lang folder. 
*/
$lang_new_item = "novo evento engadido";
$lang_title_notification = "desde a t�a �ltima visita";
$lang_update_agenda = "evento da axenda actualizado";
$lang_new_agenda = "novo evento engadido na axenda";
$lang_update_announcements = "anuncio actualizado";
$lang_new_announcements = "novo anuncio engadido";
$lang_new_document = "novo/s documento/s engadido/s";
$lang_new_exercise = "novo exercicio dispo�ible";
$lang_update_link = "informaci�n actualizada da ligaz�n";
$lang_new_link = "nova ligaz�n engadida";
$lang_new_forum_topic = "novo tema engadido";
$lang_new_groupforum_topic = "novo tema engadido � foro do grupo";
$lang_new_dropbox_file = "recibiuse un novo ficheiro";
$lang_update_dropbox_file = "Actualizouse un ficheiro do teu buz�n de tarefas";
$ForumCategoryAdded = "Engadiuse unha categor�a ao foro";
$LearnpathAdded = "Itinerario de aprendizaxe engadido";
?>