<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langViewCourseMaterialImport  = "Visualizza i contenuti del corso dopo l\'importazione";
$langViewExternalLinksImport  = "Visualizza i collegamenti esterni dopo l\'importazione";
$langViewForumImport  = "Visualizza i forum dopo l\'importazione";
$langImportCourseMaterial  = "Importa  i contenuti del corso (Modulo Blackboard \"Course Material\")";
$langImportExternalLinks  = "Importa collegamenti (Modulo Blackboard \"External Links\")";
$langImportForum  = "Importa Forum (Modulo Blackboard  \"Discussion Board\")";
$langToolInfo  = "Questo strumento importa i corsi versione 5.5  (Materiali Corso, Discussion Board, e Links esterni). ";
$langToolName = "Importa corsi Blackboard";
$langSelectCoursePackage = "Seleziona un package di corso";
$langPackageAlreadySelected = "Hai gi� selezionato il package";
$langFirstSelectPackage = "Prima di importare un package devi selezionarlo ed aprirlo";
$langCourseToMigrate = "Corso verso cui migrare";
$langSelectPackage = "Seleziona un package";
$langOpenPackageForImporting = "Apri questo package per importarlo";
$langInformation = "Informazioni sul processo di importazione";
$langChooseImportOptions = "Scegli le opzioni di importazione";
$langCheckWhatIsImported = "Puoi segnare quali elementi debbano essere importati prima di iniziare l\'importazione";
$langStartImporting = "Fai partire l\'importazione";
$langImport = "Importa";
?>