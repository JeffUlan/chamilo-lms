<?php /*
for more information: see languages.txt in the lang folder. 
*/
$select = "Seleziona";
$square = "Rettangolo";
$circle = "Ellisse";
$poly = "Poligono";
$status1 = "Traccia una zona cliccabile";
$status2_poly = "Usa il tasto destro del mouse per chiudere il poligono.";
$status2_other = "Rilascia il tasto del mouse per salvare la zona cliccabile";
$status3 = "Zona cliccabile salvata";
$exercise_status_1 = "Status: il quesito non � ancora completato";
$exercise_status_2 = "Clicca per immettere le risposte al quesito";
$exercise_status_3 = "Status: quesito completato.";
$showUserPoints = "Mostra/Nascondi i click";
$showHotspots = "Mostra/Nascondi le zone cliccabili";
$labelPolyMenu = "Chiudi il poligono";
$triesleft = "Tentativi rimasti";
$exeFinished = "Tutte le risposte sono state fornite. Ora puoi risistemare le scelte o fare click per inviare la risposta";
$nextAnswer = "Ora clicca su &done=done";
$delineation = "Delimita";
$labelDelineationMenu = "Chiudi la delimitazione";
?>