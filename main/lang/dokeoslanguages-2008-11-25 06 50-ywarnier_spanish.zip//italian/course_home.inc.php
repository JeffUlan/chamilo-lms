<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langActivate = "Mostra";
$langDeactivate = "Nascondi";
$langInLnk  = "Collegamenti nascosti";
$langDelLk = "Vuoi veramente eliminare il collegamento?";
$langEnter  = "Entra";
$langCourseCreate  = "Crea un corso";
$langNameOfTheLink  = "Nome del collegamento";
$lang_main_categories_list                  = "Categorie";
$langCourseAdminOnly = "Solo docenti";
$PlatformAdminOnly = "Solo amministratori";
$langCombinedCourse = "Corso combinato";
$ToolIsNowVisible = "Ora lo strumento � visibile";
$ToolIsNowHidden = "Ora lo strumento non � pi� visibile";
$EditLink = "Modifica il collegamento";
$Blog_management = "Gestione dei Blog";
$Forum = "Forum";
$Course_maintenance = "Manutenzione del corso";
$TOOL_SURVEY = "Questionari";
$GreyIcons = "Strumenti";
$Interaction = "Interazione";
$Authoring = "Contenuti";
$Administration = "Gestione";
$IntroductionTextUpdated = "Testo introduttivo modificato";
$IntroductionTextDeleted = "Testo introduttivo eliminato";
?>