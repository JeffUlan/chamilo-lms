<?php /*
for more information: see languages.txt in the lang folder. 
*/
$Tools  = "Strumenti";
$langDownloadFile = "Carica il documento";
$langTooBig = "Non � stato selezionato nessun documento o la dimensione � eccessiva.";
$langListDeleted = "L\'elenco � stato eliminato completamente.";
$langDocModif = "Il titolo del documento � stato modificato";
$langDocAdd = "Il documento � stato aggiunto";
$langDocDel = "Il documento � stato eliminato";
$langTitleWork = "Titolo del documento";
$langAuthors = "Autori";
$langDelList = "Elimina l\'intero elenco";
$langWorkDelete = "Elimina";
$langWorkModify = "Modifica";
$langWorkConfirmDelete = "Desideri veramente eliminare questo file";
$langAllFiles = "Applica a tutti i documenti";
$lang_default_upload = "Impostazione di default per la visibilit� dei nuovi file inviati";
$lang_new_visible = "Tutti potranno vedere i nuovi documenti inviati";
$lang_new_unvisible = "Solo i gestori del corso potranno vedere i nuovi documenti inviati";
$lang_doc_unvisible = "Il docente ha scelto di rendere visibile il tuo documento solo ai gestori del corso, quindi anche tu non potrai vederlo.";
$langDelLk = "Elimina il collegamento";
$langMustBeRegisteredUser = "Solo i corsisti iscritti possono pubblicare documenti.";
$langListDel = "Elimina i documenti elencati";
$langNameDir = "Rinomina la cartella";
$langFileExists = "Il file � gi� esistente";
$langDirCr = "Crea una cartella";
$langCurrentDir = "Cartella in uso";
$UploadADocument = "Carica un documento";
$EditToolOptions = "Modifica le opzioni";
$DocumentDeleted = "Documento eliminato";
$SendMailBody = "Un utente ha inviato un documento nella sezione Elaborati del tuo corso";
$DirDelete = "Elimina la cartella";
$ValidateChanges = "Conferma le modifiche";
$FolderUpdated = "Cartella aggiornata";
?>