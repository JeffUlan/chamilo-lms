<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langCourseProgram  = "Descrizione del Corso";
$langThisCourseDescriptionIsEmpty  = "Questo corso non � stato ancora descritto";
$langEditCourseProgram  = "Crea o modifica la descrizione";
$QuestionPlan  = "Domande rivolte al docente";
$langInfo2Say  = "Informazioni da fornire ai corsisti";
$langOuAutreTitre  = "Titolo";
$langNewBloc  = "Altro";
$langAddCat  = "Aggiungi una categoria";
$langAdd  = "Aggiungi";
$langValid  = "Conferma";
$langBackAndForget  = "Annulla";
$CourseDescriptionUpdated = "Descrizione del corso aggiornata";
$CourseDescriptionDeleted = "Descrizione del corso eliminata";
$CourseDescriptionIntro = "Clicca sulla voce e compila il modulo per creare una descrizione.<br><br>Clicca Conferma per salvare.";
?>