<?php /*
for more information: see languages.txt in the lang folder. 
*/
$langTool = "Metadati";
$langClickKw = "Clicca sulla Parola chiave nell\'albero per selezionarla o deselezionarla";
$langKwHelp = "<br/>Fai Click sul pulsante \'+\' per aprire e su \'-\' per chiudere; \'++\' apre tutto e \'--\' chiude tutto.<br/> <br/>Cancella le Parole chiave selezionate richiudendo l\'albero e riaprendolo di nuovo con il pulsante \'+\' .Alt-click \'+\' riseleziona le Parole chiave precedentemente selezionate.<br/> <br/>Alt-click Parola chiave nega la parola chiave<br/> <br/>";
$langAdvanced = "Avanzata";
$langSearch = "Cerca";
$langSearchCrit = "Usa l\'area sottostante per la descrizione, usando una parola per linea.";
$langNoKeywords = "Il corso non contiene Parole chiave";
$langKwCacheProblem = "Non � possibile aprire la cache delle parole chiave";
$langCourseKwds = "parole chiave del corso";
$langKwdsInMD = "parole chiave impiegate dei Metadati";
$langKwdRefs = "Parole chiave di riferimento";
$langNonCourseKwds = "Parole chiave non del corso";
$langKwdsUse = "Parole chiave del corso (grassetto = non impiegate)";
$langTotalMDEs = "Numero totale di metadati immessi:";
?>