<?php /*
for more information: see languages.txt in the lang folder. 
*/
$Inbox  = "In entrata";
$Messages = "Messaggi";
$SendMessage = "Invia un messaggio";
$NewMessage = "Nuovo messaggio";
$ComposeMessage = "Componi un messaggio";
$DeleteSelectedMessages = "Elimina i messaggi selezionati";
$SelectAll = "Seleziona tutto";
$DeselectAll  = "Deseleziona tutto";
$ReplyToMessage = "Rispondi";
$BackToInbox = "Torna ai messaggi in entrata";
$MessageSentTo = "Il messaggio � stato inviato a";
$SendMessageTo = "Invia a";
$Myself = "me stesso";
$From = "Da";
$To = "A";
$Date = "Data";
$InvalidMessageId = "L\'identificativo del messaggio cui rispondere non � valido";
$ErrorSendingMessage = "C\'� stato un errore nel tentativo di spedire un messaggio";
$SureYouWantToDeleteSelectedMessages = "Sei sicuro di voler eliminare i messaggi selezionati?";
$SelectedMessagesDeleted = "I messaggi selezionati sono stati eliminati";
?>